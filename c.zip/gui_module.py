from tkinter import *
from tkinter import ttk
import geoip2.database
from geoip2.errors import AddressNotFoundError
import win32con
import win32api
import threading
import os
import sys
import math
from bitprocs import load_data
import global_vars

"""
Procedures for the main GUI(after the client starts):
"""


def update_progress():
    """
    updates the progress bar
    :return: None
    """
    global wind
    global pbar
    global plabel
    global pval
    pval = global_vars.d_perc
    pbar['value'] = pval
    plabel['text'] = f'{pval}%'
    if pval < 100:
        wind.after(100, update_progress)


def set_pause():
    """
    responding command to the pause button
    :return: None
    """
    if not global_vars.pause:
        global_vars.pause = True

    else:
        global_vars.pause = False
    print(global_vars.pause)


def set_sterm():
    """
    responding command to the terminate button when leeching / X button in the main window
    activated ONLY after confirm_terminate()
    :return:
    """
    global wind
    global_vars.terminate = True
    wind.destroy()
    threading.main_thread().join()


def confirm_terminate():
    """
    confirms the termination of the client
    :return: success of return
    """
    ret = win32api.MessageBox(None, f"Are you Sure\n"
                                    f"you want to terminate the client?\n"
                                    f"(All progress will be lost)", "Warning Box",
                              win32con.MB_YESNO | win32con.MB_ICONWARNING | win32con.MB_DEFBUTTON1 | win32con.MB_TASKMODAL | win32con.MB_SERVICE_NOTIFICATION)
    if ret == win32con.IDNO:
        print("You are still here")
    elif ret == win32con.IDYES:
        set_sterm()
    return ret


def ask_seed():
    """
    will pop up after the download finishes
    :return: success of return
    """
    ret = win32api.MessageBox(None, f"Download of file finished successfully\n"
                                    f"Do you want to keep seeding on file?\n", "Warning Box",
                              win32con.MB_YESNO | win32con.MB_ICONQUESTION | win32con.MB_DEFBUTTON1 | win32con.MB_TASKMODAL | win32con.MB_SERVICE_NOTIFICATION)
    if ret == win32con.IDNO:
        print("SUCCESS!!!!")
        wind.destroy()
        threading.main_thread().join()
    elif ret == win32con.IDYES:
        global_vars.seed = True
    return ret


def child_window(btxt, bnum):
    """
    main child window proc
    :return: None
    """
    global curr_cw
    global wind
    global infostr
    global peerinfo_btn
    global recvinfo_btn
    global torrinfo_btn
    c_window = Toplevel(wind)
    c_window.title(btxt + " Window")

    torrinfo_btn.configure(state='disabled')
    recvinfo_btn.configure(state='disabled')
    peerinfo_btn.configure(state='disabled')
    pause_btn.configure(state='disabled')
    term_btn.configure(state='disabled')
    wind.protocol("WM_DELETE_WINDOW", lambda: None)  # Disable the close button
    c_window.protocol("WM_DELETE_WINDOW", close_childw)

    curr_cw = c_window
    infow = Text(c_window, fg="white", bg="#222222")
    if bnum == 1:
        threading.Thread(target=handle_torrdata, args=()).start()
    elif bnum == 2:
        threading.Thread(target=handle_downinfo, args=()).start()
    else:  # bnum == 3
        threading.Thread(target=handle_peerdata, args=()).start()
    while infostr == "":
        pass

    infow.insert(END, f'--------------------------------------------------------------------------------'
                      f'{infostr}\n'
                      f'--------------------------------------------------------------------------------')
    infostr = ""
    scrollbar = Scrollbar(c_window)
    scrollbar.pack(side=RIGHT, fill=Y)
    scrollbar.config(command=infow.yview)
    infow.config(yscrollcommand=scrollbar.set)
    infow.pack(fill=BOTH, expand=True)
    infow.configure(state='disabled')
    # Create a button to go back to the main window
    back_button = Button(c_window, text="Go Back", command=close_childw, fg="white", bg="#000066")
    back_button.pack()


def handle_torrdata():
    """
    sub-proc 1 of child_window()
    :return: None
    """
    global infostr
    t_cont = global_vars.t_content
    datast = "This window shows the data of the torrent file\n" \
             "of the downloading file(it explains about different\n" \
             "important parts of the file in detail)\n"
    title_list = ['Main Tracker(does not have to be an active tracker):\n ',
                  '\nSecondary Trackers(this client tries to use more than one): ',
                  '\nSource of the downloading file: ',
                  '\nCreator of the file: ',
                  '\nCreation date of the file: ',
                  '\nEncoding of the file: ',
                  ('\nMore info about the file: ', {b'length': '\n  File length(in bytes): ',
                                                    b'name': '\n  File name(original name in website): ',
                                                    b'piece length': '\n  Length of each piece of the file: ',
                                                    b'pieces': '\n  Hashed file data(scroll down to see more): '})]
    for title_n in range(len(title_list)):
        dcont = list(t_cont.values())[title_n]
        if title_n != len(title_list) - 1:
            datast += title_list[title_n]
            if type(dcont) == list:
                for tracker in [t[0] for t in dcont]:
                    datast += f'\n  -{tracker.decode()}'
            else:
                datast += str(dcont)

        else:
            datast += title_list[title_n][0]
            for subt in list(title_list[title_n][1].items()):
                datast += subt[1]
                if subt != list(title_list[title_n][1].items())[-1]:
                    datast += str(dcont[subt[0]])
                else:
                    datast += f'{str(dcont[subt[0]][:10])}...'
    infostr = datast


def handle_downinfo():
    """
    sub-proc 2 of child_window()
    :return: None
    """
    global infostr
    data_map = global_vars.dmap
    save_dmap = global_vars.smap

    datast = "This window shows the different info that peers respond with to the client,\n" \
             "not all data is correct(has valid hash) and that's why the verified data " \
             "and the unverified data are separated(one part shows only the live and unverified\n" \
             "responses that the client receives for each (piece, block) and the second part\n" \
             "shows which pieces are verified and which are not)\n" \
             "#Live packets disappear after their piece gets verified\n" \
             "Live Packets(unverified): \n"
    if data_map != {}:
        for p_b in list(data_map.items()):
            datast += f' -Piece {p_b[0][0]}, Block {p_b[0][1]}: {p_b[1]}\n'
    else:
        datast += f' -No live packets(either the messages process did not start or seeding)\n'

    if save_dmap != {}:
        datast += "Pieces verification: \n"
        for p in list(save_dmap.items()):
            datast += f' -Piece {p[0]}: {p[1]}\n'
    else:
        datast += f' -No verified packets(verified pieces database did not initialize yet)\n'

    infostr = datast


def handle_peerdata():
    """
    sub-proc 3 of child_window()
    :return: None
    """
    global infostr
    psinfo = global_vars.peers_info
    choking = global_vars.cpeers_info
    datast = "This window shows different data about all of\n" \
             "the peers that are connected to the client\n"

    if psinfo == {}:
        datast += f'The client is not connected to any peers right now\n'

    for p in list(psinfo.items()):
        datast += f'{p[0]}:\n'
        try:
            ipdata = geoip2.database.Reader('path_to_geolite2_database.mmdb').city(p[0][0])
            datast += f' -Description:\n'
            try:
                datast += f'  -Continent:{ipdata.continent.name}\n'
            except FileNotFoundError:
                datast += f'  -Continent:Unavailable\n'

            try:
                datast += f'  -Country:{ipdata.country.name}\n'
            except FileNotFoundError:
                datast += f'  -Country:Unavailable\n'

            try:
                datast += f'  -City:{ipdata.city.name}\n'
            except FileNotFoundError:
                datast += f'  -City:Unavailable\n'

            try:
                datast += f'  -Time Zone:{ipdata.location.time_zone}\n'
            except FileNotFoundError:
                datast += f'  -Time Zone:Unavailable\n'

        except AddressNotFoundError:
            datast += f' -Description: could not find any additional data about peer\n'
        except FileNotFoundError:
            datast += f' -Description: could not find any additional data about peer\n'

        datast += f' -Bitfield: {p[1][0]}\n' \
                  f' -Is the peer a seeder: {p[1][1]}\n' \
                  f' -Amount of blocks received from peer: {p[1][2]}\n' \
                  f' -Is the peer choking the client: {p in list(choking.keys())}\n'
    infostr = datast


def close_childw():
    """
    responding command to the X button / "Go Back" button in the child window, relevant to proc child_window()
    :return: None
    """
    global curr_cw
    global wind
    global peerinfo_btn
    global torrinfo_btn
    global recvinfo_btn
    torrinfo_btn.configure(state='normal')
    recvinfo_btn.configure(state='normal')
    peerinfo_btn.configure(state='normal')
    pause_btn.configure(state='normal')
    term_btn.configure(state='normal')
    wind.protocol("WM_DELETE_WINDOW", confirm_terminate)  # Disable the close button
    curr_cw.destroy()


def main_setup():
    global wind
    global pause_btn
    global term_btn
    global torrinfo_btn
    global recvinfo_btn
    global peerinfo_btn
    global pbar
    global plabel
    wind = Tk()
    wind.title("Bittorrent Client")
    pause_btn = Button(wind, text="Pause", command=set_pause, fg="black", bg="#FFFF00")
    term_btn = Button(wind, text="Terminate", command=confirm_terminate, fg="black", bg="#FF0000")
    button_frame = Frame(wind, background="#222222")
    torrinfo_btn = Button(button_frame, fg="white", bg="#000066", text="File Info",
                          command=lambda text="File Info": child_window(text, 1))
    recvinfo_btn = Button(button_frame, fg="white", bg="#000066", text="Received Data",
                          command=lambda text="Received Data": child_window(text, 2))
    peerinfo_btn = Button(button_frame, fg="white", bg="#000066", text="Peers Info",
                          command=lambda text="Peers Info": child_window(text, 3))
    pbar = ttk.Progressbar(wind, orient='horizontal', length=500, mode='determinate')
    plabel = ttk.Label(wind, text='0%', foreground="white", background="#222222")
    wind.protocol("WM_DELETE_WINDOW", confirm_terminate)
    genexpl = Text(wind, fg="white", bg="#222222", height=15)
    genexpl.insert(END, f'--------------------------------------------------------------------------------'
                           f'                       CYBER BITTORRENT CLIENT VERSION 1.0                      \n\n\n'
                           f'Downloading File: {global_vars.fname.split(".")[0]}\n\n'
                           f'File extension: {global_vars.fname.split(".")[1]}\n\n'
                           f'Source website: https://nyaa.si/\n\n'
                           f'File number(in website): {global_vars.tnum}\n\n\n'
                           f'      (github: https://github.com/shaygitub/bittorrent, Published in: 2023)     '
                           f'--------------------------------------------------------------------------------')

    genexpl.pack()
    genexpl.configure(state='disabled')
    button_frame.pack(side=BOTTOM, fill=Y)
    pause_btn.pack(side=LEFT, fill=Y)
    term_btn.pack(side=RIGHT, fill=Y)
    pbar.pack(pady=10)
    plabel.pack()
    update_progress()
    # Create five side buttons
    torrinfo_btn.pack(side=LEFT, pady=10)
    recvinfo_btn.pack(side=LEFT, pady=10)
    peerinfo_btn.pack(side=LEFT, pady=10)

    # Start the Tkinter event loop
    wind.protocol("WM_DELETE_WINDOW", confirm_terminate)
    wind.configure(bg="#222222")
    wind.mainloop()


"""
Procedures for GUI before client starts:
"""


def specific_seed():
    """
    first window, handles the option in which the client has a downloaded file he wants to seed on,
    this file HAS to be a copy of the file in the website with the current torrent number(starts at the first one
    in clbit.torr_numbers)
    :return: None
    """
    global ask_upld
    global upld_entry
    ask_upld = Tk()
    ask_upld.minsize(width=550, height=250)
    ask_upld.maxsize(width=550, height=250)
    ask_upld.resizable(False, False)
    ask_upld.geometry("550x250")
    ask_upld.configure(bg="#a9a9a9")
    ask_upld.protocol("WM_DELETE_WINDOW", terminate_upload)
    upld_entry = Entry(ask_upld, fg="red", bg="#a9a9a9")
    submit_name = Button(ask_upld, text="Submit name", command=check_name)
    delete_nentr = Button(ask_upld, text="Delete entry", command=lambda: upld_entry.delete(0, END))
    submit_exit = Button(ask_upld, text="Exit", command=terminate_upload)
    upname_msg = Label(ask_upld, text="If you have a downloaded file you want to start seeding from:\n"
                                             "write the file's name and press submit name,\n"
                                             "else you can press exit / the x button\n"
                                             "P.S-YOU HAVE TO ADD THE EXTENSION", fg="red", bg="#a9a9a9", height=4)

    upname_msg.pack()
    upld_entry.pack()
    submit_exit.pack()
    delete_nentr.pack()
    submit_name.pack()
    ask_upld.mainloop()


def check_name():
    """
    checks if the name provided by the user is:
    1) of an existing file in the current running directory
    2) with the same length of the original file
    :return: None
    """
    global file_name
    global upld_entry
    global piece_len
    global ask_upld
    global piece_r
    name = upld_entry.get()
    upld_entry.delete(0, END)
    if name == "":
        upld_entry.insert(0, "EMPTY")
    elif not os.path.exists(name):
        upld_entry.insert(0, "DOESN'T EXIST")
    else:
        with open(name, 'rb') as f:
            data = f.read()
            if math.ceil(float(len(data) / piece_len)) != len(piece_r) + 1:  # file is not full
                upld_entry.insert(0, "INVALID DATA")
            else:
                file_name = name  # actual possible file
                ask_upld.destroy()


def terminate_upload():
    """
    activated when the user presses the x button/ exit button
    :return: None
    """
    global file_name
    global dec_type
    og_dt = dec_type
    dec_type = 3
    decision = confirm_choice()
    if decision == win32con.IDYES:
        if file_name != "":
            file_name = ""
        ask_upld.destroy()
    dec_type = og_dt


def handle_input():
    """
    handles the input received from the user in the window before the client starts
    :return: None
    """
    global init_params
    global entry
    global rename
    global entry_r
    global submit_r
    global befw
    inp = entry.get()
    if init_params == 0:  # text file exists - either pause or termination error that stopped the client
        init_params = inp
        befw.destroy()

    else:  # actual full file exists(only has values of 1/0)
        if inp == "r":
            rename.pack()
            entry_r.pack()
            submit_r.pack()
            submit.configure(state="disabled")
            befw.update()
            init_params = ["r", ""]
        else:  # inp == o - overwrite current file / else - seeding
            init_params = inp
            befw.destroy()


def handle_renameinp():
    """
    handles the input for the rename entry
    :return: None
    """
    global entry_r
    global init_params
    global befw
    init_params[1] = entry_r.get()
    befw.destroy()


def confirm_choice():
    """
    Uses winapi to confirm the user's choice
    :return:
    """
    global dec_type
    dec_types = {0: "exit", 1: "pause", 2: "rename to the name you chose", 3: "not upload another file"}
    ret = win32api.MessageBox(None, f"Are you Sure\n you want to {dec_types[dec_type]}?", "Warning Box",
                              win32con.MB_YESNO | win32con.MB_ICONWARNING | win32con.MB_DEFBUTTON1 | win32con.MB_TASKMODAL | win32con.MB_SERVICE_NOTIFICATION)
    if ret == win32con.IDNO:
        # TODO: add code
        print("You are still here")
    elif ret == win32con.IDYES:
        # TODO: add code
        print("You are sure about leaving")
    return ret


def x_pressed():
    """
    activates when the user presses the x button on the window before the client starts
    :return: None
    """
    global x_status
    global befw
    decision = confirm_choice()
    if decision == win32con.IDYES:
        if x_status == 0:
            sys.exit(0)
        else:  # x_status = 1
            befw.destroy()


def main_init(fn, piece_range, block_range, base_id, piece_length):
    """
    Main procedure of the initiation process of client, shows the next screens:
    1) option to start from seeding on a specific, fitting file
    2) option to start seeding on specific file with the og filename / option to keep downloading from an earlier,
    failed download
    :param fn: original file name
    :param piece_range: range of pieces of file
    :param block_range: range of blocks of file
    :param base_id: base id of peer(not used for now)
    :param piece_length: the length of each piece in bytes
    :return: initiated values for several other important variables
    """
    global init_params
    global pause_term
    global befw
    global x_status
    global entry
    global down_warning
    global file_name
    global submit
    global rename
    global submit_r
    global entry_r
    global piece_len
    global piece_r
    piece_r = piece_range
    piece_len = piece_length
    seeding = False
    is_from_last = False
    last_written = 0
    down_pieces = {}
    dm = {}
    sdm = {}
    specific_seed()
    if file_name == "":
        file_name = fn

    befw = Tk()
    befw.minsize(width=550, height=250)
    befw.maxsize(width=550, height=250)
    befw.resizable(False, False)
    befw.geometry("550x250")
    befw.configure(bg="#a9a9a9")
    befw.protocol("WM_DELETE_WINDOW", x_pressed)

    entry = Entry(befw, fg="red", bg="#a9a9a9")
    submit = Button(befw, text="Submit", command=handle_input)
    pause_term = Label(
        befw, text="Data found about earlier download attempt(error has occurred)\n"
        "Do you want to continue downloading from the last attempt on OG file name? (y=yes,else=no)-> ", fg="red", bg="#a9a9a9",
        height=3)
    rename = Label(befw, text="Write new name for this download of file:", fg="red", bg="#a9a9a9", height=1)
    entry_r = Entry(befw, fg="red", bg="#a9a9a9")
    submit_r = Button(befw, text="Submit", command=handle_renameinp)

    if os.path.exists(file_name):
        with open(file_name, 'rb') as file:
            file_data = file.read()
        if math.ceil(float(len(file_data) / piece_length)) == len(piece_range) + 1:  # last download WAS successful
            down_warning = Label(befw, text="WARNING!\n"
                                        "-Quitting before ANY input - default of seeding on downloaded file\n"
                                        "-Quitting while rename - regular download on original file name + () + ext",
                                        fg="red", bg="#a9a9a9", height=3)

            file_exists = Label(befw, text="Already has file:\n"
                                                  "o=overwrite it\n"
                                                  "r=add name data for this download's name(format: file name from torrent(your addition).ext\n"
                                                  f"else=keep seeding on file(name of file: {file_name})-> ", fg="red",
                                       bg="#a9a9a9", height=4)
            init_params = 1
            down_warning.pack()
            file_exists.pack()
            entry.pack()
            submit.pack()
            befw.mainloop()
            if init_params == "o":
                os.remove(file_name)
            elif type(init_params) != list:
                seeding = True
            else:
                file_name = f'{file_name.split(".")[0]}({init_params[1]}).{file_name.split(".")[1]}'

        else:  # file name is the og file name and file is not complete
            init_params = 0
            x_status = 1
            pause_term.pack()
            entry.pack()
            submit.pack()
            befw.mainloop()
            if init_params == "y":  # continue download from last attempt
                with open(file_name, 'rb') as f:
                    datal = len(f.read())
                if datal != 0:
                    is_from_last = True
                    dm, sdm, last_written, down_pieces = load_data(file_name, piece_range, block_range, piece_length)
                else:
                    os.remove(file_name)
            else:
                os.remove(file_name)
            x_status = 0

    if not seeding:
        if not is_from_last:
            for n_piece in piece_range:
                for n_block in block_range:
                    dm[(n_piece, n_block)] = False
    return dm, sdm, is_from_last, file_name, last_written, down_pieces, seeding


"""
Global variables for GUI before the client starts
"""
befw = ""
curr_win = ""
ask_upld = ""

upld_entry = ""
entry = ""
entry_r = ""

submit = ""
submit_r = ""

pause_term = ""
down_warning = ""
rename = ""

file_name = ""
piece_r = ""
piece_len = 0
dec_type = 0
x_status = 0  # default of 0 = pressed to totally exit the program, 1 = specific use like declining an offer
init_params = -1  # determines what init input proc needs to get and what init_start() will get

"""
Global variables for GUI after the client starts(main GUI)
"""
wind = ""
pause_btn = ""
term_btn = ""
torrinfo_btn = ""
torrinfo = ""
recvinfo_btn = ""
recvinfo = ""
peerinfo_btn = ""
peerinfo = ""
pbar = ""
plabel = ""
curr_cw = ""
infostr = ""
pval = 0

