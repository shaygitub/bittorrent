
import os
import sys
import shutil
import subprocess
import socket
import subprocess
import ctypes
import math
import time
import random
import struct
import tkinter as reg_tk
import tkinter.ttk as themed_tk
from import_all import imp_all

imp_all(['cryptography', 'pywin32', 'bitstring', 'kamene'], __file__)
import cryptography
import win32con
from kamene.all import *
from kamene.layers.inet import IP, TCP, UDP, ICMP
import win32api
from bitstring import BitArray
"""
IMPORTANT PROCS FOR COMMUNICATING WITH PEERS AND ACHIEVING DATA ABOUT PEERS
"""


def create_clntid():
    base_id = "-SH7110-"
    c_id = base_id
    for i in range(20-len(c_id)):
        c_id += str(random.randrange(0, 10))
    return base_id, c_id


def check_ipvalid(ipadr):
    if ipadr.count('.') != 3:
        return False
    ip_f = ipadr.split('.')
    for f in ip_f:
        if not f.isnumeric() or int(f) < 0 or int(f) > 255:
            return False
    resp = sr1(IP(ipdst=ipadr) / ICMP(), timeout=3)
    if resp is None:
        return False
    return True


def decode_peers(peers_bytes):
    ip_ports = {}
    for i in range(0, len(peers_bytes), 6):
        ip_bytes = peers_bytes[i:i+4]
        port_bytes = peers_bytes[i+4:i+6]
        ip = socket.inet_ntoa(ip_bytes)
        prt = int.from_bytes(port_bytes, byteorder='big')
        ip_ports[(ip, prt)] = ()
    return ip_ports


def check_seeder(bf, piece_num):
    last_psize = piece_num % 8
    last_part = bf[-1]  # last byte of bitfield(last 8 pieces)
    for bf_part in bf:
        if bf_part != last_part:
            if bf_part != 255:
                return False
        else:
            last_part = BitArray(uint=last_part, length=8)
            for i in range(last_psize):
                if last_part[i] != 1:
                    return False
    return True


def can_distribute(piece_indx, p_bitfield):
    for bf_byte in range(len(p_bitfield)):
        if (bf_byte + 1) * 8 - 1 >= piece_indx:
            place = BitArray(uint=p_bitfield[bf_byte], length=8)
            if place[piece_indx % 8] == 1:  # bit is up, has piece
                return True
            else:  # bit is down, does not have piece
                return False


def get_distributed(p, dm):
    distr_data = []
    for d in list(dm.items()):
        if type(d[1]) not in [bytes, bytearray, bool]:
            if p == d[1][0]:  # this data piece_block was distributed to this peer
                distr_data.append(d[0])  # (pieceindex, blockindex)
    return distr_data


"""
HANDLING THE TORRENT FILE READING, PARSING, PRINTING, EXTRACTING IMPORTANT DATA AND SAVING
"""


def handle_tfile(metad):
    cont = {"announce": metad[b'announce'], "announce-list": metad[b'announce-list'], "comment": metad[b'comment'],
            "created by": metad[b'created by'], "creation date": metad[b'creation date'],
            "encoding": metad[b'encoding'], "info": metad[b'info']}
    return cont


def print_tcontent(t_content):
    for item in t_content.items():
        if item[0] != "info":
            print(f'{item[0]} ->', item[1])
        else:
            print(f'{item[0]} ->')
            print("=========INFO START=========")
            print(f'length ->', item[1][b'length'])
            print(f'name ->', item[1][b'name'])
            print(f'piece length ->', item[1][b'piece length'])
            print(f'pieces ->', item[1][b'pieces'])
            print("=========INFO END=========")


def save_tfile_stats(t_content):
    with open("bittorstats.txt", "wb") as f:
        for item in t_content.items():
            f.write(f'{item[0]} -> '.encode())
            if item[0] != "info":
                if item[0] == "announce-list":
                    for tracker in item[1]:
                        f.write(tracker[0] + b'  ')
                elif type(item[1]) == int:
                    f.write(str(item[1]).encode())
                else:
                    f.write(item[1])
            else:
                f.write(b'\n')
                f.write(b'=========INFO START=========' + b'\n')
                f.write(f'length -> '.encode() + str(item[1][b'length']).encode() + b'\n')
                f.write(f'name -> '.encode() + item[1][b'name'] + b'\n')
                f.write(f'piece length -> '.encode() + str(item[1][b'piece length']).encode() + b'\n')
                f.write(f'pieces -> '.encode() + item[1][b'pieces'] + b'\n')
                f.write(b'=========INFO END=========' + b'\n')
            f.write(b'\n')


def get_sha1(pieces_sha1):
    pieces = []
    for i in range(0, len(pieces_sha1) - 1, 20):
        if i + 20 <= len(pieces_sha1):
            pieces.append(pieces_sha1[i: i+20])
        else:
            pieces.append(pieces_sha1[i:])
    return pieces  # sha1 of each piece


"""
PROCS THAT HAVE SOMETHING TO DO WITH CONNECTIONS TO PEERS
"""


def handle_wsize_zero(p_sckt):
    recv_window_size = p_sckt.getsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF)
    while recv_window_size == 0:
        time.sleep(1)
        recv_window_size = p_sckt.getsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF)


def disable_firewall():  # opens ports that will be open and reachable for passive Nodes(will not be blocked by NAT/Firewall)
    # todo WHEN USING: CONTROL PANNEL,user accounts, change slider to one above bottom
    # Display a UAC prompt and request elevation
    exe_path = sys.executable
    script_path = __file__

    # Display a UAC prompt and request elevation
    ret = ctypes.windll.shell32.ShellExecuteW(None, "runas", exe_path, script_path, None, 1)

    # Check if there was an error
    if ret <= 32:
        print(f"ShellExecuteW returned {ret}")
        raise ValueError("Failed to elevate privileges")

    # Wait for the launched process to exit
    process_handle = ctypes.windll.kernel32.OpenProcess(0, False, ret)
    if process_handle:
        ctypes.windll.kernel32.WaitForSingleObject(process_handle, -1)
        ctypes.windll.kernel32.CloseHandle(process_handle)

    if ctypes.windll.shell32.IsUserAnAdmin():
        subprocess.run(
            ["netsh", "advfirewall", "firewall", "add", "rule", "name=Allow BitTorrent", "dir=in", "action=allow",
             "protocol=TCP", "localport=49152-65535"])


"""
PROCS ABOUT UPLOADING DATA, HANDLING BITFIELDS, ETC...
"""


def update_bitfield(bf, new_piece):
    new_bf = b''
    for bf_byte in range(len(bf)):
        if (bf_byte + 1) * 8 - 1 >= new_piece:
            place = BitArray(uint=bf[bf_byte], length=8)
            place[new_piece % 8] = 1
            new_bf += struct.pack("B", place.uint)
        else:
            new_bf += struct.pack("B", bf[bf_byte])
    return new_bf


"""
PROCS FOR THE USER INERFACE -tkinter
"""


def upload_fname():
    global ask_upld
    global upld_entry
    ask_upld = reg_tk.Tk()
    ask_upld.minsize(width=550, height=250)
    ask_upld.maxsize(width=550, height=250)
    ask_upld.resizable(False, False)
    ask_upld.geometry("550x250")
    ask_upld.configure(bg="#a9a9a9")
    ask_upld.protocol("WM_DELETE_WINDOW", upld_xpressed)
    upld_entry = reg_tk.Entry(ask_upld, fg="red", bg="#a9a9a9")
    submit_name = reg_tk.Button(ask_upld, text="Submit name", command=check_name)
    delete_nentr = reg_tk.Button(ask_upld, text="Delete entry", command=lambda: upld_entry.delete(0, reg_tk.END))
    submit_exit = reg_tk.Button(ask_upld, text="Exit", command=upld_xpressed)
    upname_msg = reg_tk.Label(ask_upld, text="If you have a downloaded file you want to start seeding from:\n"
                                             "write the file's name and press submit name,\n"
                                             "else you can press exit / the x button\n"
                                             "P.S-YOU HAVE TO ADD THE EXTENSION", fg="red", bg="#a9a9a9", height=4)

    upname_msg.pack()
    upld_entry.pack()
    submit_exit.pack()
    delete_nentr.pack()
    submit_name.pack()
    ask_upld.mainloop()


def handle_init():
    global init_params
    global entry
    global rename
    global entry_r
    global submit_r
    global befw
    inp = entry.get()
    if init_params == 0:  # text file exists - either pause or termination error that stopped the client
        init_params = inp
        befw.destroy()

    else:  # actual full file exists(only has values of 1/0)
        if inp == "r":
            rename.pack()
            entry_r.pack()
            submit_r.pack()
            submit.configure(state="disabled")
            befw.update()
            init_params = ["r", ""]
        else:  # inp == o - overwrite current file / else - seeding
            init_params = inp
            befw.destroy()


def handle_initr():
    global entry_r
    global init_params
    global befw
    init_params[1] = entry_r.get()
    befw.destroy()


def make_sure():
    global dec_type
    dec_types = {0: "exit", 1: "pause", 2: "rename to the name you chose", 3: "not upload another file"}
    ret = win32api.MessageBox(None, f"Are you Sure\n you want to {dec_types[dec_type]}?", "Warning Box",
                              win32con.MB_YESNO | win32con.MB_ICONWARNING | win32con.MB_DEFBUTTON1 | win32con.MB_TASKMODAL | win32con.MB_SERVICE_NOTIFICATION)
    if ret == win32con.IDNO:
        # TODO: add code
        print("You are still here")
    elif ret == win32con.IDYES:
        # TODO: add code
        print("You are sure about leaving")
    return ret


def x_pressed():
    global dec_type
    decision = make_sure()
    if decision == win32con.IDYES:
        sys.exit(0)


def upld_xpressed():
    global file_name
    global dec_type
    og_dt = dec_type
    dec_type = 3
    decision = make_sure()
    if decision == win32con.IDYES:
        if file_name != "":
            file_name = ""
        ask_upld.destroy()
    dec_type = og_dt


def check_name():
    global file_name
    global upld_entry
    global piece_len
    global ask_upld
    global piece_r
    name = upld_entry.get()
    upld_entry.delete(0, reg_tk.END)
    if name == "":
        upld_entry.insert(0, "EMPTY")
    elif not os.path.exists(name):
        upld_entry.insert(0, "DOESN'T EXIST")
    else:
        with open(name, 'rb') as f:
            data = f.read()
            if math.ceil(float(len(data) / piece_len)) != len(piece_r) + 1:
                upld_entry.insert(0, "INVALID DATA")
            else:
                file_name = name  # actual possible file
                ask_upld.destroy()


befw = ""
curr_win = ""
ask_upld = ""

upld_entry = ""
entry = ""
entry_r = ""

submit = ""
submit_r = ""

pause_term = ""
down_warning = ""
rename = ""

file_name = ""
piece_r = ""
piece_len = 0
dec_type = 0  # default of 0 = exit
init_params = -1  # determines what init input proc needs to get and what init_start() will get
"""
PROCS ABOUT USER INTERFACE
"""


def init_start(fn, piece_range, block_range, base_id, piece_length):
    global init_params
    global pause_term
    global befw
    global entry
    global down_warning
    global file_name
    global submit
    global rename
    global submit_r
    global entry_r
    global piece_len
    global piece_r
    piece_r = piece_range
    piece_len = piece_length
    seeding = False
    is_from_last = False
    target_file = -1
    last_written = 0
    down_pieces = {}
    dm = {}
    sdm = {}
    upload_fname()
    if file_name == "":
        file_name = fn

    befw = reg_tk.Tk()
    befw.minsize(width=550, height=250)
    befw.maxsize(width=550, height=250)
    befw.resizable(False, False)
    befw.geometry("550x250")
    befw.configure(bg="#a9a9a9")
    befw.protocol("WM_DELETE_WINDOW", x_pressed)

    entry = reg_tk.Entry(befw, fg="red", bg="#a9a9a9")
    submit = reg_tk.Button(befw, text="Submit", command=handle_init)
    pause_term = reg_tk.Label(
        befw, text="Data found about earlier download attempt(download was paused or error has occurred)\n"
        "Do you want to continue downloading from the last attempt? (y=yes,else=no)-> ", fg="red", bg="#a9a9a9",
        height=3)
    rename = reg_tk.Label(befw, text="Write new name for this download of file:", fg="red", bg="#a9a9a9", height=1)
    entry_r = reg_tk.Entry(befw, fg="red", bg="#a9a9a9")
    submit_r = reg_tk.Button(befw, text="Submit", command=handle_initr)

    if os.path.exists(f'{file_name}.txt'):
        with open(f'{file_name}.txt', 'rb') as f:
            down_name = f.read().split(b'\n')[1]
        init_params = 0
        pause_term.pack()
        entry.pack()
        submit.pack()
        befw.mainloop()
        if init_params == "y" and os.path.exists(down_name):  # continue download from last attempt
            is_from_last = True
            dm, sdm, last_written, down_pieces = load_data(file_name, base_id, piece_range, block_range, piece_length)
        else:
            os.remove(f'{file_name}.txt')
            if os.path.exists(down_name):
                os.remove(down_name)
        #print(
        #    "Data found about earlier download attempt(download was paused or error has occurred)")
        #if input("Do you want to continue downloading from the last attempt? (y=yes,else=no)-> ").lower() == "y":
        #    is_from_last = True
        #    dm, sdm, last_written, down_pieces = load_data(fn, base_id, piece_range, block_range, piece_length)
        #else:
        #    os.remove(fn)
        #    os.remove(f'{fn}.txt')  # remove data from last attempt

    else:  # file was never downloaded before / last download was successful
        if os.path.exists(file_name):  # last download might have been successful / file accidentally left in folder unfinished
            with open(file_name, 'rb') as file:
                file_data = file.read()
            if math.ceil(float(len(file_data) / piece_length)) == len(piece_range) + 1:  # last download WAS successful
                down_warning = reg_tk.Label(befw, text="WARNING!\n"
                                            "-Quitting before ANY input - default of seeding on downloaded file\n"
                                            "-Quitting while rename - regular download on original file name + () + ext",
                                            fg="red", bg="#a9a9a9", height=3)

                file_exists = reg_tk.Label(befw, text="Already has file:\n"
                                           "o=overwrite it\n"
                                           "r=add name data for this download's name(format: file name from torrent(your addition).ext\n"
                                           f"else=keep seeding on file(name of file: {file_name})-> ", fg="red",
                                           bg="#a9a9a9", height=4)
                init_params = 1
                down_warning.pack()
                file_exists.pack()
                entry.pack()
                submit.pack()
                befw.mainloop()
                if init_params == "o":
                    os.remove(file_name)
                elif type(init_params) != list:
                    seeding = True
                else:
                    file_name = f'{file_name.split(".")[0]}({init_params[1]}).{file_name.split(".")[1]}'

            else:  # somehow an un-finished file is in folder
                os.remove(file_name)

    if not seeding:
        if not is_from_last:
            for n_piece in piece_range:
                for n_block in block_range:
                    dm[(n_piece, n_block)] = False
            target_file = open(file_name, 'wb')  # TARGET FILE
        else:
            target_file = open(file_name, 'ab')  # TARGET FILE
    return dm, sdm, target_file, is_from_last, file_name, last_written, down_pieces, seeding


def load_data(fn, base_id, piece_range, block_range, piece_length):  # upload data from earlier iteration about the remaining pieces
    upld_dmap = {}
    upld_saved = {}
    upld_down = {}
    with open(f'{fn}.txt', 'rb') as saved_file:
        cipher = Fernet(base_id)
        pcs_data = cipher.decrypt(saved_file.read()).split(b'\n')
    last_written = int(pcs_data[0].decode().split(':')[1])  # last written index
    down_name = pcs_data[1]
    last_pindex = len(piece_range)
    with open(down_name, 'rb') as down_file:
        down_data = down_file.read()
    os.rename(down_name, fn)
    for i in range(0, last_written):
        upld_down[i] = down_data[i * piece_length: (i+1) * piece_length]
    down_pieces = upld_down

    for i in range(last_written + 1, last_pindex):
        if pcs_data[i - last_written] == b'NA':  # piece was not successful
            upld_saved[i] = False
            if i == last_pindex:  # last piece always has only 2 blocks
                upld_dmap[(last_pindex, 0)] = False
                upld_dmap[(last_pindex, 1)] = False
            else:
                for b in block_range:
                    upld_dmap[(i, b)] = False
        else:  # piece was successful
            upld_saved[i] = pcs_data[i]
    return upld_dmap, upld_saved, last_written, down_pieces


def save_data(fn, save_dmap, last_saved, last_pindex, base_id, writtento_file):  # save data about remaining pieces - data of piece if successful, NA if not
    file_data = b''
    down_name = str(last_saved)
    while os.path.exists(down_name):
        down_name += 't'
    writtento_file.close()
    os.rename(fn, down_name)
    with open(f'{fn}.txt', 'wb') as rem_file:
        file_data += f'last index of written to file:{last_saved}\n{down_name}\n'.encode()
        for i in range(last_saved + 1, last_pindex):  # all of the ones that were not saved
            if type(save_dmap[i]) in [bytes, bytearray]:  # if this piece was successful
                file_data += save_dmap[i] + '\n'.encode()
            else:  # if this piece was not successful
                file_data += "NA\n".encode()
        cipher = Fernet(base_id)
        rem_file.write(cipher.encrypt(file_data))


def upload_log(upload_to, piece_indx, piece_offset, upload_size, too_big):
    print(f'----UPLOAD----\n'
          f'to: {upload_to}\n'
          f'piece index: {piece_indx}\n'
          f'offset in piece: {piece_offset}\n'
          f'first block index: {int(piece_offset / 16384)}\n'
          f'upload size: {upload_size}\n'
          f'did exceed the limit(upload size was exceeding the piece data): {too_big}\n'
          f'last block index: {int((piece_offset + upload_size) / 16384)}\n'
          f'----END----')
