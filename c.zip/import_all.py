import sys
import subprocess


def imp_all(pckgs, filename):
    if type(pckgs) == str:  # txt file name
        with open(pckgs, 'r') as f:
            pckgs = f.read().split('\n')

    for pckg in pckgs:
        try:
            if pckg != "":
                subprocess.check_call([sys.executable, '-m', 'pip', 'install', pckg])
        except subprocess.CalledProcessError:
            print(f'Package {pckg} can not be downloaded to project {filename}, exiting script...')
            sys.exit(-1)
        except Exception as e:
            print(f'Package downloading of {pckg} has raised an error: {e}')
            sys.exit(-1)
