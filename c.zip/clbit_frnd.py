import os
import sys
import socket

target_f = ""
name = ""
piece_num = 0


def log_recv(n):
    print(f'PIECE RECEIVED-> {n}')


def get_file(sip, bport, wait):
    global piece_num
    global name
    global target_f
    self_term = False
    s = socket.socket()
    s.bind(("0.0.0.0", bport))
    if wait:
        connected = False
        while not connected:
            try:
                s.accept()
                connected = True
            except:
                pass
            if self_term:
                print('Quitting the wait..')
                target_f.close()
                os.remove(name)
                sys.exit(0)

    if not wait:
        s.accept()
    else:
        wait = False

    n_size = int(s.recv(1))
    name, pieces_num, peers_data = s.recv(n_size).decode().split('~')
    peers = peers_data.split(',')  # todo(maybe) add option to also get from other peers
    if target_f == "":
        target_f = open(name, 'wb')

    while piece_num != pieces_num:
        if self_term:
            s.send(b'QUIT')
            target_f.close()
            s.close()
            os.remove(name)
            sys.exit(0)

        s.send(b'GETP' + str(piece_num).encode())
        p_size = int(s.recv(2).decode())
        target_f.write(s.recv(p_size)[5:])
        log_recv(piece_num)
        piece_num += 1
        try:
            mcode = s.recv(5)
            if mcode == b'SELFT':
                print(f'Seeder ({sip, bport}) disconnected, quitting..')
                target_f.close()
                s.close()
                os.remove(name)
                sys.exit(-1)
            else:  # paused
                print(f'Seeder ({sip, bport}) paused, waiting for renew..')  # add button on gui to quit waiting
                s.close()
                get_file(sip, bport, True)
        except:
            pass
    s.close()
    target_f.close()
    print(f'Full file downloaded, name = {name}..')


def main(seedip, bport):
    get_file(seedip, bport, False)


if __name__ == "__main__":
    try:
        main(sys.argv[1], sys.argv[2])
    except:
        main("127.0.0.1", 5555)



