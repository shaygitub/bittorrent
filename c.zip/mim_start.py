import tkinter as tk
import geoip2.database
from geoip2.errors import AddressNotFoundError
import sys
from tkinter import ttk
import win32con
import win32api

#TODO MOVE ALL INTERFACE HERE
#TODO IF IN CHILD WINDOW DISABLE X OF WIND
#TODO IF IN CHILD WINDOW DETECT X AND DO THE SAME AS CHILD WINDOW
#TODO MAKE SIZES LOOK NORMAL AND COLOR LIKE IN BITPROCS


def update_progress():
    global pval
    global wind
    global pbar
    global plabel
    pval += 10
    pbar['value'] = pval
    plabel['text'] = f'{pval}%'
    if pval < 100:
        wind.after(1000, update_progress)


def set_pause():
    global pause
    if not pause:
        pause = True


def make_sure():
    ret = win32api.MessageBox(None, f"Are you Sure\n"
                                    f"you want to terminate the client?\n"
                                    f"(All progress will be lost)", "Warning Box",
                              win32con.MB_YESNO | win32con.MB_ICONWARNING | win32con.MB_DEFBUTTON1 | win32con.MB_TASKMODAL | win32con.MB_SERVICE_NOTIFICATION)
    if ret == win32con.IDNO:
        print("You are still here")
    elif ret == win32con.IDYES:
        set_sterm()
    return ret


def ask_seed():
    global seeding
    ret = win32api.MessageBox(None, f"Download of file finished successfully\n"
                                    f"Do you want to keep seeding on file?\n", "Warning Box",
                              win32con.MB_YESNO | win32con.MB_ICONQUESTION | win32con.MB_DEFBUTTON1 | win32con.MB_TASKMODAL | win32con.MB_SERVICE_NOTIFICATION)
    if ret == win32con.IDNO:
        wind.destroy()
        sys.exit(0)
    elif ret == win32con.IDYES:
        seeding = True
    return ret


def set_sterm():
    global self_term
    global wind
    self_term = True
    wind.destroy()


def handle_torrdata(t_content):
    datast = "This window shows the data of the torrent file\n" \
             "of the downloading file(it explains about different\n" \
             "important parts of the file in detail)\n"
    title_list = ['Main Tracker(does not have to be an active tracker): ',
                  '\nSecondary Trackers(this client tries to use more than one): ',
                  '\nSource of the downloading file: ',
                  '\nCreator of the file: ',
                  '\nCreation date of the file: ',
                  '\nEncoding of the file: ',
                  ('\nMore info about the file: ', {b'length': '\n  File length(in bytes): ',
                                                    b'name': '\n  File name(original name in website): ',
                                                    b'piece length': '\n  Length of each piece of the file: ',
                                                    b'pieces': '\n  Hashed file data(scroll down to see more): '})]
    for title_n in range(len(title_list)):
        dcont = list(t_content.values())[title_n]
        if title_n != len(title_list) - 1:
            datast += title_list[title_n]
            if type(dcont) == list:
                for tracker in [t[0] for t in dcont]:
                    datast += f'\n  -{tracker.decode()}'
            else:
                datast += str(dcont)

        else:
            datast += title_list[title_n][0]
            for subt in list(title_list[title_n][1].items()):
                datast += subt[1]
                datast += str(dcont[subt[0]])
    return datast


def handle_downinfo(dmap, smap, lastw):
    datast = "This window shows the different info that peers respond with to the client,\n" \
             "not all data is correct(has valid hash) and that's why the verified data " \
             "and the unverified data are separated(one part shows only the live and unverified\n" \
             "responses that the client receives for each (piece, block) and the second part\n" \
             "shows which pieces are verified and which are not)\n" \
             "Live Packets(unverified): \n"
    for p_b in list(dmap.items()):
        st = 'Not received'
        if type(p_b[1]) in [bytes, bytearray]:
            st = 'Received, not verified'
        datast += f' -Piece {p_b[0][0]}, Block {p_b[0][1]}: {st}\n'

    datast += "Pieces verification: \n"
    for p in list(smap.items()):
        st = 'Unverified'
        if type(p[1]) in [bytes, bytearray]:
            if lastw >= p[0]:
                st = 'Written to file'
            else:
                st = 'Verified'
        datast += f' -Piece {p[0]}: {st}\n'

    return datast


def handle_peerdata(psinfo, choking):
    datast = "This window shows different data about all of\n" \
             "the peers that are connected to the client\n"

    for p in list(psinfo.items()):
        datast += f'{p[0]}:\n'
        try:
            ipdata = geoip2.database.Reader('path_to_geolite2_database.mmdb').city(p[0][0])
            datast += f' -Description:\n' \
                      f'  -Continent:{ipdata.continent.name}\n' \
                      f'  -Country:{ipdata.country.name}\n' \
                      f'  -City:{ipdata.city.name}\n' \
                      f'  -Time zone:{ipdata.location.time_zone}\n'
        except AddressNotFoundError:
            datast += f' -Description: could not find any additional data about peer\n'

        datast += f' -Bitfield: {p[1][0]}\n' \
                  f' -Is the peer a seeder: {p[1][1]}\n' \
                  f' -Amount of blocks received from peer: {p[1][2]}\n' \
                  f' -Is the peer choking the client: {p in list(choking.keys())}\n'
    return datast


def open_child_window(btxt):
    global curr_cw
    # Function to open a child window
    child_window = tk.Toplevel(wind)
    child_window.title(btxt + " Window")

    infostr = ""
    bnum = int(btxt[-1])
    last_written = 0  # todo WHEN MOVING CHANGE TO GLOBAL LAST_WRITTEN
    save_dmap = {}  # todo WHEN MOVING CHANGE TO GLOBAL SAVE_DMAP
    data_map = {}  # todo WHEN MOVING CHANGE TO GLOBAL DATA_MAP
    t_cont = {}  # todo WHEN MOVING TO MAIN CHANGE T_CONT TO GLOBAL DICT THAT GETS CALLED TO PRINT_DATA
    peers = {}  # todo WHEN MOVING TO MAIN CHANGE PEERS TO GLOBAL PEERS
    choking_peers = {}  # todo WHEN MOVING TO MAIN CHANGE CHOKING_PEERS TO GLOBAL CHOKING_PEERS
    b1.configure(state='disabled')
    b2.configure(state='disabled')
    b3.configure(state='disabled')
    curr_cw = child_window
    infow = tk.Text(child_window)
    if bnum == 1:
        infostr = handle_torrdata(t_cont)
    elif bnum == 2:
        infostr = handle_downinfo(data_map, save_dmap, last_written)
    elif bnum == 3:
        infostr = handle_peerdata(peers, choking_peers)
    infow.insert(tk.END, infostr)
    scrollbar = tk.Scrollbar(child_window)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    scrollbar.config(command=infow.yview)
    infow.config(yscrollcommand=scrollbar.set)
    infow.pack(fill=tk.BOTH, expand=True)
    infow.configure(state='disabled')
    # Create a button to go back to the main window
    back_button = tk.Button(child_window, text="Go Back", command=close_childw)
    back_button.pack()


def close_childw():
    global curr_cw
    b1.configure(state='normal')
    b2.configure(state='normal')
    b3.configure(state='normal')
    curr_cw.destroy()


self_term = False
pause = False
seeding = False
filen, fileext = r'C:\something\anothersomth\blahblah\tempfile', '.txt'

wind = tk.Tk()
curr_cw = ""
wind.title("Main Window")
genexpl = tk.Text(wind)
genexpl.insert(tk.END, f'The name of the file that is being downloaded: {filen}\n'
                      f'The extension of the file: {fileext}')

pause_btn = tk.Button(wind, text="Pause", command=set_pause)
term_btn = tk.Button(wind, text="Terminate", command=make_sure)
pbar = ttk.Progressbar(wind, orient='horizontal', length=200, mode='determinate')
button_frame = tk.Frame(wind)
genexpl.pack()
genexpl.configure(state='disabled')
button_frame.pack(side=tk.BOTTOM, fill=tk.Y)
pause_btn.pack(side=tk.LEFT, fill=tk.Y)
term_btn.pack(side=tk.RIGHT, fill=tk.Y)


plabel = ttk.Label(wind, text='0%')
pval = 0
pbar.pack(pady=10)
plabel.pack()
update_progress()
# Create five side buttons
b1 = tk.Button(button_frame, text="Button 1", command=lambda text="Button 1": open_child_window(text))
b2 = tk.Button(button_frame, text="Button 2", command=lambda text="Button 2": open_child_window(text))
b3 = tk.Button(button_frame, text="Button 3", command=lambda text="Button 3": open_child_window(text))
b1.pack(side=tk.LEFT, pady=10)
b2.pack(side=tk.LEFT, pady=10)
b3.pack(side=tk.LEFT, pady=10)

# Start the Tkinter event loop
wind.mainloop()
