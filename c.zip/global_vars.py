seed = False
terminate = False
pause = False
d_finished = False
dmap = {}
smap = {}
peers_info = {}
cpeers_info = {}
t_content = {}
tnum = 0
d_perc = 0
c_uploads = 0
fname = ""
BLOCK_SIZE = 16384  # 16KB, not required to be this value

