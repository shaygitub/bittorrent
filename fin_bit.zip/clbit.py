import bitprocs
import global_vars
import gui_module
from bitprocs import *
import threading
import datetime
import requests
import hashlib
import bencodepy
from kamene.all import *
from kamene.layers.inet import IP, TCP, UDP, ICMP

GENERAL_TIMEOUT = 90  # MAX amount of seconds a peer has to distribute a piece / generally used timeout

torr_numbers = [1654934, 1667846, 1667837]  # short one that works,about 50 peers and out of them about 1-2 valid ones
torr_n = torr_numbers[2]
global_vars.tnum = torr_n
url = f"https://nyaa.si/download/{torr_n}.torrent"


def get_request(tracker):
    global port
    global tfile_content
    global info_hash
    global client_id
    f_len = tfile_content["info"][b'length']
    req_params = {
        "info_hash": info_hash,
        "peer_id": client_id,
        "ip": socket.gethostbyname(socket.gethostname()),
        "port": port,
        "downloaded": 0,
        "left": f_len,
        "event": "started"
    }

    return bencodepy.decode(requests.get(tracker.decode(), params=req_params).content)


def handle_tracker(tracker, tracker_n, is_init, l):
    global peers
    global tracker_checked
    global download_finished
    global seeding
    global paused
    global info_hash
    global t_threads
    global self_term
    first_iter = True
    while ((not download_finished and not seeding) or (seeding and download_finished)) and not self_term and not paused:
        try:
            if tracker_n not in (t_threads.keys()) and not first_iter:  # repetetive, not inluding start
                print(1)
                sys.exit(0)
            t_response = get_request(tracker)
            print(t_response)
            newpdict = decode_peers(t_response[b'peers'])
            for new_psvpeer in bitprocs.allow_passive(info_hash):
                newpdict[new_psvpeer[0]] = ()

            new_peers = update_peers(peers, newpdict, l)  # if not first time,only update the old list
            l.acquire()
            peers = new_peers
            global_vars.peers_info = peers
            if first_iter:
                tracker_checked.append(True)
                first_iter = False
            l.release()

            t = datetime.datetime.now()
            while (not download_finished and not seeding) or (seeding and download_finished) and not paused and not self_term:  # wait for all peers to connect
                if int((datetime.datetime.now() - t).total_seconds()) > 2500:  # waiting time
                    t = datetime.datetime.now()

                if global_vars.pause:
                    paused = True
                if global_vars.terminate:
                    self_term = True

        except requests.exceptions.InvalidSchema:
            print(f'No connection adapter was found for {tracker}')
            if first_iter:
                l.acquire()
                tracker_checked.append(True)
                l.release()
            break
        except requests.exceptions.ConnectionError:
            print(f'Existing connection was forcibly closed by tracker {tracker}')
            if first_iter:
                l.acquire()
                tracker_checked.append(True)
                l.release()
            break
    if tracker in list(t_threads.keys()):
        t_threads.pop(tracker)


def start_trackers():
    global tfile_content
    global tracker_checked
    global t_threads
    tracker_checked = []
    is_first = True
    next_t = 0

    if len(t_threads) != 0:
        next_t = list(t_threads.keys())[-1] + 1
        is_first = False
        t_threads = {}

    for trck in tfile_content["announce-list"]:
        t = threading.Thread(target=handle_tracker, args=(trck[0], next_t, is_first, lock))
        t.start()
        t_threads[next_t] = t
        next_t += 1

    s_time = datetime.datetime.now()
    timeout_period = datetime.timedelta(seconds=10)
    while tracker_checked.count(True) != len(tfile_content["announce-list"]):  # wait for all trackers to sign in peers
        pass


def update_peers(oldpdict, newpdict, l):
    global rep_count
    global p_threads
    global seeding
    updatepdict = oldpdict
    next_p = 0
    for p in newpdict.keys():
        if p not in oldpdict.keys():
            if seeding:
                updatepdict[p] = False
                pt = threading.Thread(target=handle_peer_seed, args=(p[0], p[1], l))
            else:
                updatepdict[p] = ()
                pt = threading.Thread(target=handle_peer, args=(p[0], p[1], l, rep_count))
            pt.start()
            l.acquire()
            p_threads[p] = pt
            l.release()
    return updatepdict


def handle_message(c_sckt, piece_index, block_index, b_size, req_from, is_interested):
    global target_torrentf
    global seeding
    global data_map
    global last_pindex
    global block_range
    global save_dmap
    global from_last
    global tfile_content
    req_start_offset = block_index * global_vars.BLOCK_SIZE
    res_data = ""
    try:
        if not seeding and not download_finished:
            piece_req = struct.pack("!IBIII", 13, 6, piece_index, req_start_offset, b_size)
            print(f'=====MESSAGE LOG({req_from}, p_b = ({piece_index}, {block_index})=====')
            c_sckt.send(piece_req)
            time.sleep(1)

            to = 30  # timeout of 30 seconds for response
            readable, writable, exceptional = select.select([c_sckt], [], [], to)
            if c_sckt not in readable:  # peer did not respond with piece response
                if not readable:
                    print(f'Request from Peer{req_from} not successful(Peer did not respond in a {to}sec timeframe)')
                else:
                    print(f'Request from Peer{req_from} not successful(Peer did not respond with a Piece Response)')
                return -1, is_interested

        res_data = c_sckt.recv(5)

        if res_data == b'\x00\x00\x00\x01\x00':  # peer choked me, type = 0
            return 0, is_interested

        elif res_data == b'\x00\x00\x00\x01\x02':  # peer is interested, type = 2
            is_interested = True
            bitprocs.handle_bitfield(c_sckt, last_written, from_last)
            return 2, is_interested

        elif res_data == "":  # data did not arrive at all
            if seeding:
                return 99, is_interested
            else:
                return -99, is_interested

        elif res_data == b'' or len(res_data) == 4 and res_data[0] == 0:  # keep-alive packet
            if seeding:
                return 99, is_interested
            else:
                return 10, is_interested

        elif res_data == b'\x00\x00\x00':  # can be here sometimes, not in any context - ignore
            return 99, is_interested

        elif res_data[4] == 3:  # peer is not interested, type = 3
            is_interested = False
            return 3, is_interested

        elif res_data[4] == 4:  # have message
            if seeding:
                return 99, is_interested  # not important for seeder
            else:
                p_index = c_sckt.recv(4)
                return str(struct.unpack('!I', p_index)[0]), is_interested

        elif res_data[4] == 7:  # piece message
            if seeding:
                return 99, is_interested  # not important

            else:
                res_data += c_sckt.recv(b_size + 8)  # id + length = 5, else (except piece) = 8
                res_length = struct.unpack('!I', res_data[:4])[0]
                res_id = 7
                res_pindex = struct.unpack('!I', res_data[5:9])[0]
                res_start_offset = struct.unpack('!I', res_data[9:13])[0]
                response_data = res_data[13:]
                if from_last and res_pindex <= last_written:  # no need for packet
                    return 99, is_interested

                if res_pindex > last_pindex or int(
                        res_start_offset / global_vars.BLOCK_SIZE) not in block_range:  # un-valid piece info
                    if int(res_start_offset / global_vars.BLOCK_SIZE) not in block_range:  # offset is un-valid
                        if res_pindex > last_pindex:  # index is un-valid
                            print(f"error{req_from}:un-valid piece index and piece offset"
                                  f"index->({res_pindex}), offset->({res_start_offset})")
                        else:
                            print(f"error{req_from}:un-valid piece offset({res_start_offset})")
                    else:
                        print(f"error{req_from}:un-valid piece index({res_pindex})")
                    return -3, is_interested

                if type(save_dmap[res_pindex]) not in [bytes, bytearray] and type(data_map[(res_pindex, int(res_start_offset / global_vars.BLOCK_SIZE))]) not in [bytes, bytearray]:
                    data_map[(res_pindex, int(res_start_offset / global_vars.BLOCK_SIZE))] = response_data
                    print(f'=====RESPONSE FROM PEER{req_from} - Piece:{res_pindex}, block:{int(res_start_offset / global_vars.BLOCK_SIZE)}=====')
                    if res_start_offset == req_start_offset and piece_index == res_pindex:  # if the correlated piece arrived
                        return response_data, is_interested
                    return (res_pindex, int(res_start_offset / global_vars.BLOCK_SIZE),
                            response_data), is_interested  # not correlated
                else:
                    return 99, is_interested

        elif res_data[4] == 6:  # piece request
            res_data += c_sckt.recv(12)  # index, offset, size (all 4 bytes)
            bitprocs.handle_peer_upload(c_sckt, res_data, req_from, down_pieces, last_written, from_last)
            return 6, is_interested

        else:
            return 99, is_interested  # not a packet i should focus on (keep-alive, unchoke-cant be here, bitfield)

    except TimeoutError:
        if not seeding:
            print(f'Request from Peer{req_from} not successful(request time out)')
            return -1, is_interested
        else:
            return 99, is_interested

    except ConnectionAbortedError:
        print(f'Connection to Peer{req_from} was aborted in the requesting process, reconnecting..')
        return -2, is_interested

    except IndexError:
        if not seeding:
            print(f'Index error from Peer{req_from} in request of ({piece_index}, {block_index})\n'
                  f'res_data: {res_data}')
            traceback.print_exc()
        else:
            print(f'Index error from Peer{req_from} while seeding(probably in the first "recv(5)" of res_data)\n'
                  f'{res_data}')
        return -1, is_interested


def initialize(is_rep):
    global peers
    global data_map
    global piece_range
    global block_range
    global pieces_hash
    global save_dmap
    global valid_hash
    while () in peers.values():
        pass

    for piece_indx in piece_range:
        if not is_rep:
            valid_hash[piece_indx] = False
            for block_index in block_range:
                data_map[(piece_indx, block_index)] = ()

        else:
            if type(save_dmap[piece_indx]) not in [bytes, bytearray]:
                valid_hash[piece_indx] = False
                for block_index in block_range:
                    if type(data_map[(piece_indx, block_index)]) not in [bytes, bytearray]:
                        data_map[(piece_indx, block_index)] = ()

    lastp_index = tfile_content["info"][b'length'] // tfile_content["info"][b'piece length']
    if not is_rep or is_rep and type(save_dmap[lastp_index]) not in [bytes, bytearray]:
        valid_hash[lastp_index] = False
        if not is_rep or type(data_map[(lastp_index, 0)]) not in [bytes, bytearray]:
            data_map[(lastp_index, 0)] = ()
        if not is_rep or type(data_map[(lastp_index, 1)]) not in [bytes, bytearray]:
            data_map[(lastp_index, 1)] = ()


def check_allp(pindex, main_check):
    global data_map
    global pieces_hash
    global valid_hash
    piece_data = b''
    countrecv_pbs = 0
    recv_pbs = [x for x in list(data_map.items()) if x[0][0] == pindex]
    for x in recv_pbs:
        if type(x[1]) in [bytes, bytearray]:
            countrecv_pbs += 1
        else:
            pass

    if countrecv_pbs != len(recv_pbs):
        return False, False, b''

    for x in recv_pbs:
        piece_data += x[1]

    if hashlib.sha1(piece_data).digest() == pieces_hash[pindex]:
        if main_check:
            print(f'valid hash of piece {pindex}')
            valid_hash[pindex] = True
            if pindex == last_pindex:
                count_blocks[(pindex, 0)] = 1
                count_blocks[(pindex, 1)] = 1
                data_map.pop((pindex, 0))
                data_map.pop((pindex, 1))
            else:
                for b_indx in block_range:
                    count_blocks[(pindex, b_indx)] = 1
                    data_map.pop((pindex, b_indx))
            save_dmap[pindex] = piece_data  # save whole piece data in save_dmap
        return True, True, b''  # return has every piece , correct hash
    return True, False, hashlib.sha1(piece_data).digest()  # return has every piece , not correct hash


def remove_peer(rem_peer, l, sock):
    global peers
    l.acquire()
    if rem_peer in list(peers.keys()):
        peers.pop(rem_peer)
    l.release()
    sock.close()
    return False


def handle_peer_seed(p_ip, p_port, l):
    global info_hash
    global peers
    global seeding
    global handshake
    global choking_peers
    p_sckt = socket.socket()
    p_sckt.settimeout(50)

    choked = False
    isp_interested = False
    is_valid = True
    terminate = False

    interested = b'\x00\x00\x00\x01\x02'

    try:
        try:
            p_sckt.connect((p_ip, p_port))  # todo this line is the cause for the socket.timeout mass error
            p_sckt.send(handshake)
            peer_hs_response = p_sckt.recv(68)
            p_protocol_len, p_protocol, p_reserved, peer_info_hash, p_id = struct.unpack("!B19s8s20s20s",
                                                                                         peer_hs_response)
            if info_hash != peer_info_hash:  # wrong hash
                print(f'Peer({p_ip},{p_port}) responded with wrong hash,disconnecting..')
                is_valid = remove_peer((p_ip, p_port), l, p_sckt)

            else:
                bf_length, msg_id = struct.unpack('!IB', p_sckt.recv(5))
                print(bf_length, msg_id)
                bitfield = p_sckt.recv(bf_length - 1)
                unchoke_length, unchoke = struct.unpack('!IB', p_sckt.recv(5))
                print(f'bit field({p_ip},{p_port}):', bitfield)
                print(f'unchoke({p_ip},{p_port}):', unchoke)

                p_sckt.settimeout(None)
                if unchoke == 0:  # peer choked me
                    choking_peers[(p_ip, p_port)] = True, False  # ischoked,didfinishthread
                    choked_t = threading.Thread(target=bitprocs.handle_choked,
                                                args=(p_sckt, (p_ip, p_port), interested, isp_interested, down_pieces, last_written, from_last))
                    choked_t.start()
                    while choking_peers[(p_ip, p_port)][0] and not choking_peers[(p_ip, p_port)][1]:
                        if global_vars.cpeers_info[(p_ip, p_port)] != choking_peers[(p_ip, p_port)]:
                            choking_peers[(p_ip, p_port)] = global_vars.cpeers_info[(p_ip, p_port)]
                    if not choking_peers[(p_ip, p_port)][0] and choking_peers[(p_ip, p_port)][
                        1]:  # False,True , not choked anymore
                        isp_interested = choking_peers[(p_ip, p_port)][2]
                        unchoke = 1
                    choking_peers.pop((p_ip, p_port))

                if unchoke == 1 or unchoke == 255:
                    peers[(p_ip, p_port)] = (bitfield, check_seeder(bitfield,
                                             tfile_content["info"][b'length'] // tfile_content["info"][b'piece length'] + 1), 0)
                else:
                    is_valid = remove_peer((p_ip, p_port), l, p_sckt)

                if is_valid:
                    wait_time = datetime.datetime.now()
                    p_sckt.send(struct.pack("!I", 0))  # keep-alive packet
                    while not all_connected:  # wait for all peers to connect
                        if int((datetime.datetime.now() - wait_time).total_seconds()) > 120:  # wait for two minutes
                            wait_time = datetime.datetime.now()
                            p_sckt.send(struct.pack("!I", 0))  # keep-alive packet
                    p_sckt.settimeout(50)

        except socket.timeout:
            print(f'Failed Connection/Communication with Peer({p_ip},{p_port}) -> TimeOut Reached(socket)')
            is_valid = remove_peer((p_ip, p_port), l, p_sckt)

        except TimeoutError:
            print(f'Failed Connection/Communication with Peer({p_ip},{p_port}) -> TimeOut Reached(OS)')
            is_valid = remove_peer((p_ip, p_port), l, p_sckt)

        except OSError as e:
            if e.winerror == 10049:
                print(f'Failed Connection with Peer({p_ip},{p_port}) -> Un-valid address/port')
            is_valid = remove_peer((p_ip, p_port), l, p_sckt)

        if is_valid:
            while seeding and not paused and not terminate:
                if choked:
                    choking_peers[(p_ip, p_port)] = True, False  # ischoked,didfinishthread
                    choked_t = threading.Thread(target=bitprocs.handle_choked,
                                                args=(p_sckt, (p_ip, p_port), interested, isp_interested, down_pieces, last_written, from_last))
                    choked_t.start()
                    while choking_peers[(p_ip, p_port)][0] and not choking_peers[(p_ip, p_port)][1]:
                        if global_vars.cpeers_info[(p_ip, p_port)] != choking_peers[(p_ip, p_port)]:
                            choking_peers[(p_ip, p_port)] = global_vars.cpeers_info[(p_ip, p_port)]

                    if choking_peers[(p_ip, p_port)][0] and choking_peers[(p_ip, p_port)][
                        1]:  # still choked after max iterations
                        remove_peer((p_ip, p_port), l, p_sckt)
                        choking_peers.pop((p_ip, p_port))
                        terminate = True
                        continue
                    else:  # False,True , not choked anymore
                        choked = False
                        isp_interested = choking_peers[(p_ip, p_port)][2]
                        choking_peers.pop((p_ip, p_port))

                try:
                    res_data, isp_interested = handle_message(p_sckt, -1, -1, -1, (p_ip, p_port), isp_interested)

                except socket.timeout:
                    res_data = 99

                except ConnectionResetError:
                    print(f'Failed Communication with Peer({p_ip},{p_port}) -> Connection forcibly closed by peer')
                    remove_peer((p_ip, p_port), l, p_sckt)
                    terminate = True
                    continue

                if res_data == 0:  # peer choked client
                    choked = True

                elif res_data != -1:  # an error did not happen
                    if res_data in [6, 2, 3,
                                    99]:  # message is request /interested/ not interested/ do not need to deal with
                        pass

                    elif res_data == -2:  # connection aborted
                        pt = threading.Thread(target=handle_peer_seed, args=(p_ip, p_port, l))
                        pt.start()
                        p_threads[(p_ip, p_port)] = pt
                        p_sckt.close()
                        sys.exit(0)

                else:  # ERROR
                    pass
                handle_wsize_zero(p_sckt)
            p_sckt.close()

        if not terminate and is_valid:
            remove_peer((p_ip, p_port), l, p_sckt)
        if (p_ip, p_port) in list(p_threads.keys()):
            p_threads.pop((p_ip, p_port))

    except ConnectionRefusedError:
        print(f'Could not connect to Peer({p_ip},{p_port}) -> target refused connection')
        remove_peer((p_ip, p_port), l, p_sckt)
        p_threads.pop((p_ip, p_port))
        sys.exit(0)

    except ConnectionResetError:
        print(f'Existing connection to Peer({p_ip},{p_port}) was forcibly closed')
        remove_peer((p_ip, p_port), l, p_sckt)
        p_threads.pop((p_ip, p_port))
        sys.exit(0)

    except struct.error:
        print(f'Wrong sizes in Peer({p_ip},{p_port}) handshake response data')
        remove_peer((p_ip, p_port), l, p_sckt)
        p_threads.pop((p_ip, p_port))
        sys.exit(0)

    except ConnectionAbortedError:
        print(f'Existing connection to Peer({p_ip},{p_port}) was aborted by this PC, re-trying connection..')
        pt = threading.Thread(target=handle_peer_seed, args=(p_ip, p_port, l))
        pt.start()
        p_threads[(p_ip, p_port)] = pt
        p_sckt.close()
        sys.exit(0)


def handle_peer(p_ip, p_port, l, rep_num):
    global client_id
    global info_hash
    global data_map
    global peers
    global tfile_content
    global handshake
    global GENERAL_TIMEOUT
    global choking_peers
    global target_torrentf
    global download_finished
    global is_distributed
    global lastp_lock
    global last_pindex
    global last_block_size
    global last_piece_size
    p_sckt = socket.socket()
    p_sckt.settimeout(50)

    kalive_time = ""
    nothing_count = 0

    terminate = False
    is_keep_alive = False
    choked = False
    is_seeder = False
    isp_interested = False
    is_valid = True

    interested = b'\x00\x00\x00\x01\x02'
    bitfield = b''

    try:
        try:
            if not paused:
                p_sckt.connect((p_ip, p_port))  # todo this line is the cause for the socket.timeout mass error
                p_sckt.send(handshake)
                peer_hs_response = p_sckt.recv(68)
                p_protocol_len, p_protocol, p_reserved, peer_info_hash, p_id = struct.unpack(">B19s8s20s20s",
                                                                                             peer_hs_response)
                if info_hash != peer_info_hash:  # wrong hash
                    print(f'Peer({p_ip},{p_port}) responded with wrong hash,disconnecting..')
                    is_valid = remove_peer((p_ip, p_port), l, p_sckt)

                else:
                    bf_length, msg_id = struct.unpack('>IB', p_sckt.recv(5))
                    print(bf_length, msg_id)
                    bitfield = p_sckt.recv(bf_length - 1)
                    unchoke_length, unchoke = struct.unpack('>IB', p_sckt.recv(5))
                    print(f'bit field({p_ip},{p_port}):', bitfield)
                    print(f'unchoke({p_ip},{p_port}):', unchoke)
                    if check_seeder(bitfield,
                                    tfile_content["info"][b'length'] // tfile_content["info"][b'piece length'] + 1):
                        is_seeder = True

                    p_sckt.settimeout(None)
                    if unchoke == 0:  # peer choked me
                        peer_data = peers[(p_ip, p_port)]
                        peers.pop((p_ip, p_port))  # until unchoked - not a contributing peer
                        choking_peers[(p_ip, p_port)] = True, False  # ischoked,didfinishthread
                        choked_t = threading.Thread(target=bitprocs.handle_choked,
                                                    args=(p_sckt, (p_ip, p_port), interested, isp_interested, down_pieces, last_written, from_last))
                        choked_t.start()
                        while choking_peers[(p_ip, p_port)][0] and not choking_peers[(p_ip, p_port)][1] and not paused:
                            if global_vars.cpeers_info[(p_ip, p_port)] != choking_peers[(p_ip, p_port)]:
                                choking_peers[(p_ip, p_port)] = global_vars.cpeers_info[(p_ip, p_port)]
                        if choking_peers[(p_ip, p_port)] in [(False, True, True),
                                                             (False, True, False)] and not paused:  # False,True , not choked anymore
                            isp_interested = choking_peers[(p_ip, p_port)][2]
                            unchoke = 1
                            peers[(p_ip, p_port)] = peer_data
                        choking_peers.pop((p_ip, p_port))

                    if unchoke == 1 or unchoke == 255:
                        peers[(p_ip, p_port)] = (bitfield, is_seeder, 0)
                    else:
                        is_valid = remove_peer((p_ip, p_port), l, p_sckt)

                    if is_valid and not paused:
                        wait_time = datetime.datetime.now()
                        p_sckt.send(struct.pack("!I", 0))  # keep-alive packet
                        while not is_distributed and not paused:  # wait for all peers to connect
                            if int((datetime.datetime.now() - wait_time).total_seconds()) > 120:  # wait for two minutes
                                wait_time = datetime.datetime.now()
                                p_sckt.send(struct.pack("!I", 0))  # keep-alive packet
                        p_sckt.settimeout(50)

        except socket.timeout:
            print(f'Failed Connection/Communication with Peer({p_ip},{p_port}) -> TimeOut Reached(socket)')
            is_valid = remove_peer((p_ip, p_port), l, p_sckt)

        except TimeoutError:
            print(f'Failed Connection/Communication with Peer({p_ip},{p_port}) -> TimeOut Reached(OS)')
            is_valid = remove_peer((p_ip, p_port), l, p_sckt)

        except OSError as e:
            if e.winerror == 10049:
                print(f'Failed Connection with Peer({p_ip},{p_port}) -> Un-valid address/port')
            is_valid = remove_peer((p_ip, p_port), l, p_sckt)

        if is_valid:
            while not download_finished and not paused and not terminate and rep_count == rep_num:
                if choked:
                    choking_peers[(p_ip, p_port)] = True, False  # ischoked,didfinishthread
                    choked_t = threading.Thread(target=bitprocs.handle_choked,
                                                args=(p_sckt, (p_ip, p_port), interested, isp_interested, down_pieces, last_written, from_last))
                    choked_t.start()
                    peer_data = peers[(p_ip, p_port)]
                    peers.pop((p_ip, p_port))  # until unchoked - not a contributing peer

                    try:
                        while choking_peers[(p_ip, p_port)][0] and not choking_peers[(p_ip, p_port)][1]:
                            if global_vars.cpeers_info[(p_ip, p_port)] != choking_peers[(p_ip, p_port)]:
                                choking_peers[(p_ip, p_port)] = global_vars.cpeers_info[(p_ip, p_port)]
                    except KeyError:
                        terminate = True
                        remove_peer((p_ip, p_port), l, p_sckt)
                        continue

                    if choking_peers[(p_ip, p_port)][0] and choking_peers[(p_ip, p_port)][1]:  # still choked after max iterations
                        choking_peers.pop((p_ip, p_port))
                        remove_peer((p_ip, p_port), l, p_sckt)
                        terminate = True
                    else:  # False,True , not choked anymore
                        choked = False
                        isp_interested = choking_peers[(p_ip, p_port)][2]
                        choking_peers.pop((p_ip, p_port))
                        peers[(p_ip, p_port)] = peer_data

                not_taken = [x[0] for x in list(data_map.items()) if type(x[1]) not in [bytes, bytearray]]
                if len(not_taken) != 0:  # if there are no not-taken pieces nothing can be done
                    piece, block = not_taken[random.randrange(0, len(not_taken))]

                    try:
                        if (piece, block) == (last_pindex, list(block_range)[-1]):  # last piece_block, might be different size
                            res_data, isp_interested = handle_message(p_sckt, piece, block,
                                                                      last_block_size,
                                                                      (p_ip, p_port), isp_interested)

                        else:
                            res_data, isp_interested = handle_message(p_sckt, piece, block, global_vars.BLOCK_SIZE,
                                                                      (p_ip, p_port), isp_interested)

                    except socket.timeout:
                        print(f'Failed Communication with Peer({p_ip},{p_port}) -> TimeOut Reached during request')
                        remove_peer((p_ip, p_port), l, p_sckt)
                        p_threads.pop((p_ip, p_port))
                        sys.exit(0)

                    except ConnectionResetError:
                        print(f'Failed Communication with Peer({p_ip},{p_port}) -> Connection forcibly closed by peer')
                        remove_peer((p_ip, p_port), l, p_sckt)
                        p_threads.pop((p_ip, p_port))
                        sys.exit(0)

                    if res_data != -99:
                        nothing_count = 0

                    if is_keep_alive and int((datetime.datetime.now() - kalive_time).total_seconds()) > 120:
                        is_keep_alive = False

                    if res_data == 0:  # peer choked client
                        choked = True
                        continue

                    elif res_data != -1:  # an error did not happen
                        if res_data == 10:  # keep-alive message
                            is_keep_alive = True
                            kalive_time = datetime.datetime.now()

                        elif res_data == -99:  # peer did not send anything
                            if not is_keep_alive:
                                nothing_count += 1
                                if nothing_count == 50:
                                    print(f'Peer({p_ip}, {p_port}) did not respond for a long time, disconnecting...')
                                    remove_peer((p_ip, p_port), l, p_sckt)
                                    terminate = True
                                    continue
                            else:
                                nothing_count = 0

                        elif res_data in [6, 2, 3,
                                        99, -3]:  # message is not piece request/ interested/ not interested/ late package or else
                            pass

                        elif res_data == -2:  # connection aborted
                            pt = threading.Thread(target=handle_peer, args=(p_ip, p_port, l, rep_count))
                            pt.start()
                            p_threads[(p_ip, p_port)] = pt
                            p_sckt.close()
                            sys.exit(0)

                        elif type(res_data) == str:  # has to be a have message
                            if int(res_data) <= last_pindex:  # check for valid piece index
                                bitfield = update_bitfield(bitfield, int(res_data))  # add piece to bitfield
                                peers[(p_ip, p_port)] = (bitfield, is_seeder, peers[(p_ip, p_port)][2])

                        elif type(res_data) in [bytes, bytearray]:  # has to be a VALID,correlated piece response
                            tempp_data = list(peers[(p_ip, p_port)])
                            tempp_data[2] += 1
                            peers[(p_ip, p_port)] = tuple(tempp_data)

                        else:  # has to be a non-correlated valid piece response, type = tuple
                            try:
                                if (p_ip, p_port) in list(peers.keys()):
                                    tempp_data = list(peers[(p_ip, p_port)])
                                    tempp_data[2] += 1
                                    peers[(p_ip, p_port)] = tuple(tempp_data)
                                    p_indx, b_indx, piece_data = res_data  # res data- (pindx,bindx,piece data)

                            except TypeError:
                                pass  # print(f'TYPE ERROR: TYPE IS {type(res_data)}')
                    else:
                        remove_peer((p_ip, p_port), l, p_sckt)
                        terminate = True
                        continue

                handle_wsize_zero(p_sckt)
            if not terminate and is_valid:
                remove_peer((p_ip, p_port), l, p_sckt)
            if (p_ip, p_port) in list(p_threads.keys()):
                p_threads.pop((p_ip, p_port))

    except ConnectionRefusedError:
        print(f'Could not connect to Peer({p_ip},{p_port}) -> target refused connection')
        remove_peer((p_ip, p_port), l, p_sckt)
        p_threads.pop((p_ip, p_port))
        sys.exit(0)

    except ConnectionResetError:
        print(f'Existing connection to Peer({p_ip},{p_port}) was forcibly closed')
        remove_peer((p_ip, p_port), l, p_sckt)
        p_threads.pop((p_ip, p_port))
        sys.exit(0)

    except struct.error:
        print(f'Wrong sizes in Peer({p_ip},{p_port}) handshake response data')
        remove_peer((p_ip, p_port), l, p_sckt)
        p_threads.pop((p_ip, p_port))
        sys.exit(0)

    except ConnectionAbortedError:
        print(f'Existing connection to Peer({p_ip},{p_port}) was aborted by this PC, re-trying connection..')
        pt = threading.Thread(target=handle_peer, args=(p_ip, p_port, l, rep_count))
        pt.start()
        p_threads[(p_ip, p_port)] = pt
        p_sckt.close()
        sys.exit(0)


def keep_checking():
    global data_map
    global save_dmap
    global valid_hash
    global pieces_hash
    global peers
    global target_torrentf
    global last_saved
    for piece_i in [p[0] for p in list(valid_hash.items()) if not p[1]]:
        got_every, is_correct_hash, hash_ofdata = check_allp(piece_i, True)
        if got_every and not is_correct_hash:
            print(
                f'unvalid hash of piece {piece_i}(in torrent file: {pieces_hash[piece_i]}, actual: {hash_ofdata})')
            for b in [x[1] for x in list(data_map.keys()) if x[0] == piece_i]:
                data_map[piece_i, b] = ()

    for full_piece in list(valid_hash.items()):  # for each piece
        if full_piece[1]:  # if all piece blocks arrived and they are hash verified
            last_saved += 1  # piece 0 - 0,1 - 0,1,2...
            target_torrentf.write(save_dmap[full_piece[0]])
            valid_hash.pop(full_piece[0])
            target_torrentf.flush()
        else:  # need to write pieces by their order
            break


def main_regular(is_rep):  # is_rep -> if this is a repeated version - all peers disconnected / ignored / etc..
    global all_connected
    global from_last
    global self_term
    global paused
    global last_saved
    global last_written
    global valid_hash
    global save_dmap
    global data_map
    global download_finished
    global peers
    global count_blocks
    global down_pieces
    global is_distributed
    global block_range
    global piece_range
    global last_d
    global GENERAL_TIMEOUT
    global count_same
    global choking_peers
    global recv_amnt
    global pieces_hash
    global target_torrentf
    global p_threads
    global rep_count

    stuck_count = 0

    if not self_term and not paused:
        start_trackers()

        while not all_connected and not self_term and not paused:
            try:
                initialize(is_rep)
                all_connected = True

            except IndexError:  # restart -> trackers did not respond
                if not self_term and not paused:
                    print("Trackers did not respond,trying again...")
                    start_trackers()

        if not self_term and not paused:
            if from_last and not is_rep:
                last_saved = last_written  # points to the index of the last saved
                for v_piece in list(valid_hash.keys()):
                    if v_piece in list(save_dmap.keys()):
                        if type(save_dmap[v_piece]) in [bytes, bytearray]:
                            valid_hash[v_piece] = True

            is_only_one = len(peers) == 1
            if is_only_one and not peers[0][1]:
                print(f'Only one peer{peers[0]} connected and he is not a seeder, Trying again...')
                rep_count += 1
                main_regular(True)

            if from_last and not is_rep:
                for piece_i in list(down_pieces.keys()):
                    for b in block_range:
                        count_blocks[(piece_i, b)] = 1

            if not is_rep:
                for x in list(data_map.keys()):
                    count_blocks[x] = 0
                if not from_last:  # if it is from earlier download-> save_dmap is already initialized
                    for x in list(data_map.keys()):
                        if x[0] not in list(save_dmap.keys()):  # if piece is not included already
                            save_dmap[x[0]] = False

            #print(data_map)
            update_dbase()
            is_distributed = True
            iter_to = datetime.datetime.now()
            last_dmap = data_map
            while not download_finished and not self_term and not paused:  # MAIN LOOP
                if peers == {}:
                    print(f'ALL PEERS DISCONNECTED, TRYING AGAIN...')
                    rep_count += 1
                    main_regular(True)

                if int((datetime.datetime.now() - iter_to).total_seconds()) >= 10:  # iter_c % 200 == 0:
                    iter_to = datetime.datetime.now()
                    if len(choking_peers) != len(peers):
                        if last_dmap == data_map:
                            stuck_count += 1
                            if stuck_count > 15:
                                print(f'No data received, retrying...')
                                rep_count += 1
                                main_regular(True)
                        else:
                            stuck_count = 0

                        last_dmap = data_map
                        recv_amnt = 0
                        for v in list(count_blocks.values()):
                            recv_amnt += v
                        print(
                            f'{float(recv_amnt / len(count_blocks)) * 100}% Received({recv_amnt} out of {len(count_blocks)} blocks), data map={len(data_map)}')
                keep_checking()

                if data_map == {} and valid_hash == {} and len(save_dmap) == len(
                        [x for x in list(save_dmap.values()) if type(x) in [bytes, bytearray]]):
                    download_finished = True
                update_dbase()
                global_vars.d_perc = float(recv_amnt / len(count_blocks)) * 100

                if global_vars.pause:
                    paused = True

                if global_vars.terminate:
                    self_term = True

        if last_saved != -1 and not paused and not self_term:  # download did start, todo ONLY FOR TROUBLESHOOTING
            print("PIECES NOT RECIEVED:")
            for x in list(data_map.items()):
                if type(x[1]) in [bytes, bytearray]:
                    print(x[0], "->", x[1][:10])
                else:
                    print(x[0], "->", x[1])
    target_torrentf.close()


def main_seed(from_beginning):
    global seeding
    global save_dmap
    global self_term
    global from_last
    global target_torrentf
    global paused
    global tfile_content
    global file_name
    global total_uploads
    global iter_c
    if not self_term and not paused:
        if from_beginning:  # seeding from beginning - everything in savedmap from file verified
            save_dmap = {}
            with open(file_name, 'rb') as fulld_file:
                down_data = fulld_file.read()
            for i in range(0, tfile_content["info"][b'length'] // tfile_content["info"][b'piece length']):
                if i == tfile_content["info"][b'length'] // tfile_content["info"][b'piece length']:
                    save_dmap[i] = down_data[i * tfile_content["info"][b'piece length']:]
                else:
                    save_dmap[i] = down_data[
                                   i * tfile_content["info"][b'piece length']: (i + 1) * tfile_content["info"][
                                       b'piece length']]

        else:
            if from_last:  # seeding after stopping - some is in file and some is from current run
                new_sdmap = down_pieces
                for new_saved in list(save_dmap.items()):
                    new_sdmap[new_saved[0]] = new_saved[1]
                save_dmap = new_sdmap

    iter_c = 0
    from_last = False
    seeding = True
    while seeding and not self_term:
        if not paused:
            handle_seed()
            if not paused:
                seeding = False
        else:
            if not global_vars.pause:  # keep GUI up and running until user unpauses / terminates client
                paused = False
    print(f'Seeding stopped, total uploads: {total_uploads}')
    seeding = False


def handle_seed():
    global seeding
    global iter_c
    global peers
    global self_term
    global all_connected
    global choking_peers
    global total_uploads
    global paused
    peers = {}
    start_trackers()
    all_connected = False
    while not all_connected:
        if self_term:
            seeding = False
            break
        if paused:
            break

        while False in peers.values():  # wait for all peers to connect
            if self_term:
                seeding = False
                break
            if paused:
                break
        try:
            peer_data = list(peers.keys())[0]
            all_connected = True

        except IndexError:
            print("Trackers did not respond,trying again...")
            start_trackers()

    if not self_term and not paused:
        while seeding:
            if len(choking_peers) == len(peers):
                print(f'All peers choked client, waiting for change..')

            if peers == {}:
                print(f'ALL PEERS DISCONNECTED, TRYING AGAIN...')
                handle_seed()

            if global_vars.terminate:
                self_term = True
                seeding = False
                break

            if global_vars.pause:
                paused = True
                break
            total_uploads = global_vars.c_uploads
            iter_c += 1


def update_dbase():
    global data_map
    global save_dmap
    global last_written

    global_vars.dmap = {}
    if data_map != global_vars.dmap:
        for p_b in list(data_map.items()):
            st = 'Not received'
            if type(p_b[1]) in [bytes, bytearray]:
                st = 'Received, not verified'
            global_vars.dmap[(p_b[0][0], p_b[0][1])] = st

    if save_dmap != global_vars.smap:
        for p in list(save_dmap.items()):
            st = 'Unverified'
            if type(p[1]) in [bytes, bytearray]:
                if last_saved >= p[0]:
                    st = 'Written to file'
                else:
                    st = 'Verified'
            global_vars.smap[p[0]] = st


requests.packages.urllib3.disable_warnings()
c = socket.socket()
c.bind(("0.0.0.0", 54321))
port = 6881

lock = threading.Lock()
lastp_lock = threading.Lock()
base_id, client_id = create_clntid()

recv_amnt = 0
iter_c = 0
count_same = 0
rep_count = 0
total_uploads = 0
last_saved = -1

is_distributed = False
download_finished = False
self_term = False
all_connected = False
paused = False

tracker_checked = []
fpeer_list = []

p_threads = {}
t_threads = {}
valid_hash = {}  # contains key = piece_block, value= true/false for is hash correct
count_blocks = {}
last_d = {}
peers = {}  # peer list for when contacting the tracker
choking_peers = {}

if not os.path.exists("bittor.torrent"):
    tfile_response = requests.get(url, verify=False)
    with open("bittor.torrent", "wb") as f:
        f.write(tfile_response.content)
    metadata = bencodepy.decode(tfile_response.content)

else:
    with open("bittor.torrent", "rb") as f:
        metadata = bencodepy.decode(f.read())

disable_firewall()  # run as administrator and open ports
tfile_content = handle_tfile(metadata)
global_vars.t_content = tfile_content

info_hash = hashlib.sha1(bencodepy.encode(tfile_content["info"], tfile_content["encoding"].decode())).digest()
hs_params = [19, b'BitTorrent protocol', b"\x00" * 8, info_hash, client_id.encode('utf-8')]
handshake = struct.pack("!B19s8s20s20s", hs_params[0], hs_params[1], hs_params[2], hs_params[3], hs_params[4])
pieces_hash = get_sha1(tfile_content["info"][b'pieces'])

last_pindex = tfile_content["info"][b'length'] // tfile_content["info"][b'piece length']
last_piece_size = tfile_content["info"][b'length'] % tfile_content["info"][b'piece length']
last_block_size = last_piece_size % global_vars.BLOCK_SIZE
piece_range = range(tfile_content["info"][b'length'] // tfile_content["info"][b'piece length'])
block_range = range(tfile_content["info"][b'piece length'] // global_vars.BLOCK_SIZE)
file_name = tfile_content["info"][b'name'].decode()
data_map, save_dmap, from_last, file_name, last_written, down_pieces, seeding = gui_module.main_init(file_name,
                                                                                                                      piece_range,
                                                                                                                      block_range,
                                                                                                                      base_id,
                                                                                                                      tfile_content[
                                                                                                                      "info"][
                                                                                                                      b'piece length'])
if not seeding:
    if from_last:
        target_torrentf = open(file_name, 'ab')  # TARGET FILE
    else:
        target_torrentf = open(file_name, 'wb')  # TARGET FILE

global_vars.fname = file_name
gui_t = threading.Thread(target=gui_module.main_setup, args=())
gui_t.start()
if not seeding:  # can seed on the file that was achieved from the beginning
    print_tcontent(tfile_content)
    save_tfile_stats(tfile_content)
    first_try = True
    while not download_finished and not self_term:
        if not paused:
            if first_try:
                first_try = False
                main_regular(False)
            else:
                main_regular(True)
            if not paused:
                download_finished = True
        else:
            if not global_vars.pause:  # keep GUI up and running until user unpauses / terminates client
                paused = False

    if last_saved == last_pindex and not self_term and download_finished:  # if downloaded everything - SUCCESSFUL
        gui_module.ask_seed()
        if global_vars.seed:
            main_seed(False)
        sys.exit(0)
    if not self_term:  # if somehow got here without stopping - save everything, some error occured
        sys.exit(-1)

    else:
        if os.path.exists(file_name):
            os.remove(file_name)
        sys.exit(0)

else:
    global_vars.seed = True
    download_finished = True
    main_seed(True)
    if self_term:  # if self_term
        sys.exit(0)
    else:
        sys.exit(-1)
