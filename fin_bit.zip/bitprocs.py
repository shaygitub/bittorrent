
from kamene.all import *
from bitstring import BitArray
import global_vars
import ctypes

"""
PROCS ABOUT TORRENT FILE(PARSING, UNDESTANDING...)
"""


def handle_tfile(metad):
    """
    creates a new-formatted torrent content dictionary
    :param metad: original meta dictionary
    :return: new formatted dictionary
    """
    cont = {"announce": metad[b'announce'], "announce-list": metad[b'announce-list'], "comment": metad[b'comment'],
            "created by": metad[b'created by'], "creation date": metad[b'creation date'],
            "encoding": metad[b'encoding'], "info": metad[b'info']}
    return cont


def print_tcontent(t_content):
    """
    prints the content of the file(from .torrent data)
    :param t_content: torrent content dictionary
    :return: None
    """
    for item in t_content.items():
        if item[0] != "info":
            print(f'{item[0]} ->', item[1])
        else:
            print(f'{item[0]} ->')
            print("=========INFO START=========")
            print(f'length ->', item[1][b'length'])
            print(f'name ->', item[1][b'name'])
            print(f'piece length ->', item[1][b'piece length'])
            print(f'pieces ->', item[1][b'pieces'])
            print("=========INFO END=========")


def save_tfile_stats(t_content):
    """
    saves the content of the .torrent file in a decoded and nicely formatted form
    :param t_content: torrent content dictionary
    :return: None
    """
    with open("bittorstats.txt", "wb") as f:
        for item in t_content.items():
            f.write(f'{item[0]} -> '.encode())
            if item[0] != "info":
                if item[0] == "announce-list":
                    for tracker in item[1]:
                        f.write(tracker[0] + b'  ')
                elif type(item[1]) == int:
                    f.write(str(item[1]).encode())
                else:
                    f.write(item[1])
            else:
                f.write(b'\n')
                f.write(b'=========INFO START=========' + b'\n')
                f.write(f'length -> '.encode() + str(item[1][b'length']).encode() + b'\n')
                f.write(f'name -> '.encode() + item[1][b'name'] + b'\n')
                f.write(f'piece length -> '.encode() + str(item[1][b'piece length']).encode() + b'\n')
                f.write(f'pieces -> '.encode() + item[1][b'pieces'] + b'\n')
                f.write(b'=========INFO END=========' + b'\n')
            f.write(b'\n')


"""
PROCS IMPORTANT FOR HOW MAIN(CLBIT.PY) OPERATES
"""


def check_seeder(bf, piece_num):
    """
    checks if a peer is a seeder
    :param bf: bitfield of peer
    :param piece_num: amount of total pieces in file
    :return: True/False
    """
    last_psize = piece_num % 8
    last_part = bf[-1]  # last byte of bitfield(last 8 pieces)
    for bf_part in bf:
        if bf_part != last_part:
            if bf_part != 255:
                return False
        else:
            last_part = BitArray(uint=last_part, length=8)
            for i in range(last_psize):
                if last_part[i] != 1:
                    return False
    return True


def handle_choked(p_sckt, choking_peer, interested_msg, is_interested, dwnpieces, last_wrtn, is_frmlast):
    """
    main thread that handles a peer that chokes the client
    :param p_sckt: socket object
    :param choking_peer: peer data (ip, port)
    :param interested_msg: interested bytearray message
    :param is_interested: was the peer interested before
    :return: None
    """
    choked_iter = 0
    is_choked = 0  # 0 = choked, 1 = not choked
    global_vars.cpeers_info[choking_peer] = True, False  # ischoked,didfinishthread
    print(f'choked by peer{choking_peer} -> iteration number {choked_iter}')
    while is_choked == 0 and choked_iter < 5 and (
            not global_vars.d_finished and not global_vars.seed or global_vars.d_finished and global_vars.seed):  # peer choked me
        try:
            p_sckt.send(interested_msg)
            choked_reply = p_sckt.recv(5)
        except TimeoutError:
            continue
        except ConnectionResetError:
            is_choked = 2
            continue
        except ConnectionAbortedError:
            is_choked = 3
            continue
        try:
            if choked_reply[4] in [0, 1]:  # 0 = choked, 1 = unchoked
                is_choked = choked_reply[4]
            elif not is_interested and choked_reply == interested_msg:  # interested
                is_interested = True
                handle_bitfield(p_sckt, last_wrtn, is_frmlast)
            elif is_interested and choked_reply[4] == 6:  # piece request
                handle_peer_upload(p_sckt, choked_reply + p_sckt.recv(12), choking_peer, dwnpieces, last_wrtn, is_frmlast)
        except IndexError:
            print(f'Peer{choking_peer} index error(choked) -> {choked_reply}')
        choked_iter += 1
        print(f'choked by peer{choking_peer} -> iteration number {choked_iter}')
        time.sleep(120)  # wait for 120 seconds until requesting again

    if global_vars.d_finished and not global_vars.seed:
        global_vars.cpeers_info[choking_peer] = (True, True, is_interested)

    elif is_choked != 1:  # unchoked
        if is_choked == 2:
            print(f'Peer{choking_peer} ended connection with client forcibly , what an asshole!')
        elif is_choked == 3:
            print(f'PC aborted connection to peer{choking_peer}, fuck him!')
        else:
            print(
                f'Peer{choking_peer} ignored client for {choked_iter} times(is_choked={is_choked}), closing connection..')
        global_vars.cpeers_info[choking_peer] = (True, True, is_interested)

    else:
        global_vars.cpeers_info[choking_peer] = (False, True, is_interested)


def form_bitfield(last_wrtn, is_frmlast):
    """
    create a bitfield
    :param last_wrtn: last written piece to file
    :param is_frmlast: did the download start from an earlier attempt
    :return: bitfield
    """
    curr_bf = b''
    every8 = BitArray(uint=0, length=8)
    num_piece = global_vars.t_content["info"][b'length'] // global_vars.t_content["info"][b'piece length'] + 1

    if global_vars.seed:
        i = 0
        for x in list(global_vars.smap.items()):
            every8[i] = 1
            if i == 7 or list(global_vars.smap.items())[-1] == x:
                curr_bf += struct.pack("B", every8.uint)
                every8 = BitArray(uint=0, length=8)
                i = 0
            else:
                i += 1
        return curr_bf

    if is_frmlast:
        for i in range((last_wrtn + 1) / 8):
            curr_bf += struct.pack("B", 255)
        for i in range((last_wrtn + 1) % 8):
            every8[i] = 1

    if global_vars.smap == {} or len(global_vars.smap) == len([x for x in list(global_vars.smap.values()) if type(x) not in [bytes,
                                                                                                        bytearray]]):  # asked for pieces when there are none
        if is_frmlast:
            curr_bf += struct.pack("B", every8.uint)
            num_piece -= (last_wrtn + 1) + (8 - (last_wrtn + 1) % 8)
        while num_piece >= 8:
            curr_bf += struct.pack("B", 0)
            num_piece -= 8
        curr_bf += struct.pack("B", BitArray(uint=0, length=num_piece))

    else:
        if is_frmlast:
            for i in range((8 - (last_wrtn + 1) % 8)):
                if type(global_vars.smap[i]) in [bytes, bytearray]:  # whole piece is in there
                    every8[(last_wrtn + 1) % 8 + i] = 1
                else:
                    every8[(last_wrtn + 1) % 8 + i] = 0
            curr_bf += every8
            for piece_indx in range((8 - (last_wrtn + 1) % 8), len(global_vars.smap) - 1):
                if type(global_vars.smap[piece_indx]) in [bytes, bytearray]:  # whole piece is in there
                    every8[(piece_indx - (8 - (last_wrtn + 1) % 8)) % 8] = 1
                else:
                    every8[(piece_indx - (8 - (last_wrtn + 1) % 8)) % 8] = 0
                if (piece_indx - (8 - (last_wrtn + 1) % 8)) % 8 == 7:  # last piece of 8 pieces group
                    curr_bf += struct.pack("B", every8.uint)
                    every8 = BitArray(uint=0, length=8)
            curr_bf += every8

        else:
            for piece_indx in range(num_piece):
                if type(global_vars.smap[piece_indx]) in [bytes, bytearray]:  # whole piece is in there
                    every8[piece_indx % 8] = 1
                else:
                    every8[piece_indx % 8] = 0
                if piece_indx % 8 == 7:  # last piece of 8 pieces group
                    curr_bf += struct.pack("B", every8.uint)
                    every8 = BitArray(uint=0, length=8)
            curr_bf += every8
    return curr_bf


def handle_bitfield(inrst_peer, last_wrtn, is_frmlast):
    """
    called when a bitfield is needed for the client
    :param inrst_peer: the peer that needs the bitfield(socket object)
    :return: None
    """
    bf_msg = b''
    bf_msg += struct.pack("!i", 1 + math.ceil(global_vars.t_content["info"][b'length'] / 8))
    bf_msg += b'\x05' + form_bitfield(last_wrtn, is_frmlast)
    inrst_peer.send(bf_msg)


def handle_peer_upload(p_sckt, data, upload_to, dwnpieces, last_wrtn, is_frmlast):
    """
    handles uploading data to a peer(THREAD)
    ASSUMES THAT PEER WILL NOT REQUEST A PIECE NOT INCLUDED IN SAVE_DMAP
    :return: None
    """
    piece_indx = struct.unpack("!I", data[5:9])[0]
    piece_offset = struct.unpack('!I', data[9:13])[0]
    upload_size = struct.unpack("!I", data[13:17])[0]
    too_big = False
    pmsg_data = b''
    if piece_indx in [list(global_vars.smap.keys()), list(dwnpieces.keys())]:  # if piece is valid
        if piece_offset + upload_size > global_vars.t_content["info"][b'piece length']:  # if sizes are not valid
            upload_size = global_vars.t_content["info"][b'piece length'] - piece_offset
            too_big = True

        if global_vars.seed:  # has every valid piece in save_dmap, whether started from saved or all in one
            pmsg_data = global_vars.smap[piece_indx][piece_offset: piece_offset + upload_size]

        else:
            if is_frmlast:
                if piece_indx <= last_wrtn:  # piece data is in down_pieces
                    pmsg_data = dwnpieces[piece_indx][piece_offset: piece_offset + upload_size]

                else:  # piece data is (might) in save_dmap
                    if type(global_vars.smap[piece_indx]) in [bytes, bytearray]:  # if piece is valid
                        pmsg_data = global_vars.smap[piece_indx][piece_offset: piece_offset + upload_size]
            else:
                if type(global_vars.smap[piece_indx]) in [bytes, bytearray]:  # if piece is valid
                    pmsg_data = global_vars.smap[piece_indx][piece_offset: piece_offset + upload_size]

        pmsg_len, pmsg_id = 9 + len(pmsg_data), 7
        piece_msg = struct.pack("!IBII", pmsg_len, pmsg_id, piece_indx, piece_offset)
        p_sckt.send(piece_msg + pmsg_data)
        upload_log(upload_to, piece_indx, piece_offset, upload_size, too_big)
        if global_vars.seed:
            global_vars.c_uploads += 1
    else:
        print(f'Piece {piece_indx} requested by peer{upload_to} is not a valid piece number / client do not have it')


"""
PROCS WITH GENERAL PURPOSE 
"""


def create_clntid():
    """
    creates the client ID for message communications
    :return: base of the id(used to encrypt files), full client id for this run
    """
    base_id = "-SH7110-"
    c_id = base_id
    for i in range(20-len(c_id)):
        c_id += str(random.randrange(0, 10))
    return base_id, c_id


def decode_peers(peers_bytes):
    """
    decodes the data about the available peers from trackers
    :return: decoded information
    """
    ip_ports = {}
    for i in range(0, len(peers_bytes), 6):
        ip_bytes = peers_bytes[i:i+4]
        port_bytes = peers_bytes[i+4:i+6]
        ip = socket.inet_ntoa(ip_bytes)
        prt = int.from_bytes(port_bytes, byteorder='big')
        ip_ports[(ip, prt)] = ()
    return ip_ports


def can_distribute(piece_indx, p_bitfield):
    """
    checks if a peer can provide data from a piece
    :param piece_indx: piece index
    :param p_bitfield: bitfield of peer
    :return:
    """
    for bf_byte in range(len(p_bitfield)):
        if (bf_byte + 1) * 8 - 1 >= piece_indx:
            place = BitArray(uint=p_bitfield[bf_byte], length=8)
            if place[piece_indx % 8] == 1:  # bit is up, has piece
                return True
            else:  # bit is down, does not have piece
                return False


def get_sha1(pieces_sha1):
    """
    extracts the hash of each piece from the file(as given from torrent file)
    used to confirm if the hash of a piece is valid or not
    :param pieces_sha1: full string of conjoined hashes
    :return:
    """
    pieces = []
    for i in range(0, len(pieces_sha1) - 1, 20):
        if i + 20 <= len(pieces_sha1):
            pieces.append(pieces_sha1[i: i+20])
        else:
            pieces.append(pieces_sha1[i:])
    return pieces  # sha1 of each piece


def handle_wsize_zero(p_sckt):
    """
    handles the occasion in which the TCP message has the window size of zero
    :param p_sckt: socket object
    :return: None
    """
    try:
        recv_window_size = p_sckt.getsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF)
        while recv_window_size == 0:
            time.sleep(1)
            recv_window_size = p_sckt.getsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF)
    except OSError:
        pass


def allow_passive(inf_hash):
    """
    allows passive peers to connect
    :return: data about new peers
    """
    new_psvpeers = []
    try:
        dht_node = btdht.DHT()
        dht_node.join_network()
        passive_peers = dht_node.get_peers(inf_hash)

        for peer in passive_peers:
            psv_ip, psv_port = peer
            new_psvpeers.append((psv_ip, psv_port))
    except:
        return []
    return new_psvpeers


def disable_firewall():  # opens ports that will be reachable for passive nodes(will not be blocked by NAT/Firewall)
    """
    opens ports that will be reachable for passive nodes(will not be blocked by NAT/Firewall)
    :return: None
    """
    # Display a UAC prompt and request elevation
    exe_path = sys.executable
    script_path = __file__

    # Display a UAC prompt and request elevation
    ret = ctypes.windll.shell32.ShellExecuteW(None, "runas", exe_path, script_path, None, 1)

    # Check if there was an error
    if ret <= 32:
        print(f"ShellExecuteW returned {ret}")
        raise ValueError("Failed to elevate privileges")

    # Wait for the launched process to exit
    process_handle = ctypes.windll.kernel32.OpenProcess(0, False, ret)
    if process_handle:
        ctypes.windll.kernel32.WaitForSingleObject(process_handle, -1)
        ctypes.windll.kernel32.CloseHandle(process_handle)

    if ctypes.windll.shell32.IsUserAnAdmin():
        subprocess.run(
            ["netsh", "advfirewall", "firewall", "add", "rule", "name=Allow BitTorrent", "dir=in", "action=allow",
             "protocol=TCP", "localport=49152-65535"])


def update_bitfield(bf, new_piece):
    """
    updates client's bitfield when a new and verified piece is confirmed
    :param bf: old bitfield
    :param new_piece: piece index
    :return: new bitfield
    """
    new_bf = b''
    for bf_byte in range(len(bf)):
        if (bf_byte + 1) * 8 - 1 >= new_piece:
            place = BitArray(uint=bf[bf_byte], length=8)
            place[new_piece % 8] = 1
            new_bf += struct.pack("B", place.uint)
        else:
            new_bf += struct.pack("B", bf[bf_byte])
    return new_bf


def load_data(fn, piece_range, block_range, piece_length):
    """
    loads data from failed earlier download attempt(used in the GUI before the client starts)
    :param fn: file name
    :param piece_range: range of pieces of file
    :param block_range: range of blocks of file
    :param piece_length: length of a single piece
    :return: several database variables with initialized values for the specific failed file
    """
    upld_dmap = {}
    upld_saved = {}
    down_pieces = {}
    with open(fn, 'rb') as saved_file:
        pcs_data = b"".join(saved_file.read().split(b'\n'))
    last_written = int(len(pcs_data) / piece_length) - 1  # last written index
    last_pindex = len(piece_range)
    for i in range(0, last_written + 1):
        down_pieces[i] = pcs_data[i * piece_length: (i+1) * piece_length]

    for i in range(last_written + 1, last_pindex + 1):
        upld_saved[i] = False
        if i == last_pindex:  # last piece always has only 2 blocks
            upld_dmap[(last_pindex, 0)] = False
            upld_dmap[(last_pindex, 1)] = False
        else:
            for b in block_range:
                upld_dmap[(i, b)] = False

    return upld_dmap, upld_saved, last_written, down_pieces


def upload_log(upload_to, piece_indx, piece_offset, upload_size, too_big):
    """
    logs an upload made to a peer
    :param upload_to: peer IP, peer port
    :param piece_indx: piece index uploaded
    :param piece_offset: starting offset of upload
    :param upload_size: amount of bytes uploaded
    :param too_big: did the peer exceed the limit of the piece data(offset + size > size of piece)
    :return:
    """
    print(f'----UPLOAD----\n'
          f'to: {upload_to}\n'
          f'piece index: {piece_indx}\n'
          f'offset in piece: {piece_offset}\n'
          f'first block index: {int(piece_offset / 16384)}\n'
          f'upload size: {upload_size}\n'
          f'did exceed the limit(upload size was exceeding the piece data): {too_big}\n'
          f'last block index: {int((piece_offset + upload_size) / 16384)}\n'
          f'----END----')
